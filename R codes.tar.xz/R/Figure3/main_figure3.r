main_figure3 <- function(

){
  # System A and C are simple codes for Green-Dry and Brown-Dry systems in R

  fig3_line_point<- function(
){
    fontsize = 12
    textsize = 3.5

     # There is a gap simulation on 2018-10-01 
     # by FLEXPART model due to mismatch of ERA5 data format and FLEXPART model
    fill_the_gap<-function(x){
      x1 = x[1:189]
      x2 = x[190:251]
     
      x3 = mean(x[189:190])
      x = c(x1,x3,x2)
      return(x)
    }
    
    library(ggpubfigs)
    input = 'data_for_sharing/Figure3/aligned_spatial_df_indices'
    input1 = paste0(input,'/twsdf.csv')
    input2 = paste0(input,'/gppdf.csv')
    input3 = paste0(input,'/rootsmdf.csv')
    input4 = paste0(input,'/evadf')
    input5 = paste0(input,'/t2mdf.csv')
    input6 = paste0(input,'/prdf.csv')
    input7 = paste0(input,'/loc.csv')
    
    twsdf = as.data.frame(fread(input1))
    gppdf = as.data.frame(fread(input2))
    rootsmdf = as.data.frame(fread(input3))
    evadf = as.data.frame(fread(input4))
    t2mdf = as.data.frame(fread(input5))
    prdf = as.data.frame(fread(input6))
    loc = as.data.frame(fread(input7))
    longlat1 = paste0(loc[,1],'_',loc[,2])
    
    #source('R/stand_trend2.R')
    input_increase_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/increase_gpp_cwsi.csv'
    input_decrease_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/decrase_gpp_cwsi.csv'
    
    inc_gpp = as.data.frame(fread(input_increase_gpp_cwsi))
    dec_gpp = as.data.frame(fread(input_decrease_gpp_cwsi))
    
    inc_gpp$long_lat = paste0(inc_gpp[,1]+ 0.125,'_',inc_gpp[,2]+ 0.125)
    dec_gpp$long_lat = paste0(dec_gpp[,1]+ 0.125,'_',dec_gpp[,2]+ 0.125)
    
    inc_gpp = inc_gpp[which(inc_gpp$CWSI<0),]
    dec_gpp = dec_gpp[which(dec_gpp$CWSI<0),]
    
    id1 = which(longlat1 %in% inc_gpp$long_lat)
    id2 = which(longlat1 %in% dec_gpp$long_lat)
    
    vpd1 = as.data.frame(fread(paste0(input,'/vpdinc.csv')))
    vpd2 = as.data.frame(fread(paste0(input,'/vpddec.csv')))
  
    loc1 = loc[id1,]
    loc2 = loc[id2,]
    sm1 = rootsmdf[id1,]
    sm2 = rootsmdf[id2,]
    tws1 = twsdf[id1,]
    tws2 = twsdf[id2,]
    gpp1 = gppdf[id1,]
    gpp2 = gppdf[id2,]
    t2m1 = t2mdf[id1,]
    t2m2 = t2mdf[id2,]
    eva1 = evadf[id1,]
    eva2 = evadf[id2,]
    pr1 = prdf[id1,]
    pr2 = prdf[id2,]
    
    stand_trend2<-function(x){
      if(is.na(mean(x))){
        x = rep(NA,240)
      }else{
        x = ts(x,start = c(2000,1),frequency = 12)
        x = decompose(x)$trend
        x = x[-which(is.na(x))]
        #x = (x-mean(x))/sd(x)
      }
      
      return(x)
    }
    calc_area_weighted_average_value_df <- function(rastdf)
    {
      # rastdf structure
      # multiple columns
      library(ClimProjDiags)
      # rast is a raster of map 
      #rastdf = as.data.frame(rast,xy = T)
      
      lon = rastdf[,1]
      lat = rastdf[,2]
      
      rastdf = rastdf[,-c(1,2)]
      i = 1:ncol(rastdf)
      subfun<-function(i){
        library(ClimProjDiags)
        library(raster)
        tmp = data.frame(
              long = lon,
              lat = lat,
              value = rastdf[,i])
        coordinates(tmp) = ~long+lat
        gridded(tmp) = T
        tmp = raster(tmp)

        tmp = as.data.frame(tmp,xy = T)
        uni_lon = unique(tmp[,1])
        uni_lat = unique(tmp[,2])
        
        value = tmp[,3]
        dim(value) = c(lon = length(uni_lon),
                      lat = length(uni_lat),time = 1)

        a = WeightedMean(value,lon=uni_lon,lat = uni_lat)
        return(a)

      }
      #value = rastdf[,3]
      
      library(doParallel)
      cl = makeCluster(20)
      registerDoParallel(cl)
      retvec = foreach(i=i) %dopar%{
        subfun(i)
      }
      stopCluster(cl)

      a = do.call(c,retvec)  
      
      return(a)
    }
    
    source('R/calc_area_weighted_average_value_df.R')
    gpp1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,gpp1)))
    gpp2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,gpp2)))
    
    tws1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,tws1)))
    tws2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,tws2)))
    
    t2m1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,t2m1)))
    t2m2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,t2m2)))
    
    sm1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,sm1)))
    sm2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,sm2)))

    eva1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,eva1)))
    eva2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,eva2)))
    
    pr1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,pr1)))
    pr2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,pr2)))

    vpd1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc1,vpd1)))
    vpd2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc2,vpd2)))

    diff_pr = pr1-pr2
    diff_sm = sm1-sm2
    diff_t2m = t2m2-t2m1
    diff_eva = eva1-eva2
    diff_vpd = vpd2-vpd1
    diff_gpp = gpp1-gpp2
    
    stand_fun <-function(x){
      x = (x-mean(x))/sd(x)
      return(x)
    }  
    
    calc_absolute_value_index <- function(x){
      meax = mean(x)
      sdx = sd(x)
      
      aimx = c(-2,-1,0,1,2)
      
      aimx = aimx * sdx+meax
      return(aimx)
    }
    
    sdiff_eva = stand_fun(diff_eva)
    sdiff_vpd = stand_fun(diff_vpd)
    sdiff_gpp = stand_fun(diff_gpp)
    sdiff_pr = stand_fun(diff_pr)
    sdiff_sm = stand_fun(diff_sm)
    sdiff_t2m = stand_fun(diff_t2m)
    
    aim_eva = calc_absolute_value_index(diff_eva)
    aim_vpd = calc_absolute_value_index(diff_vpd)
    aim_gpp = calc_absolute_value_index(diff_gpp)
    
    aim_pr = calc_absolute_value_index(diff_pr)
    aim_t2m = calc_absolute_value_index(diff_t2m)
    aim_sm= calc_absolute_value_index(diff_sm)
    
    
    aim_eva = round(aim_eva,2)
    aim_vpd = round(aim_vpd,2)
    aim_gpp = round(aim_gpp,2)
    aim_pr = round(aim_pr,2)
    aim_sm = round(aim_sm,2)
    aim_t2m = round(aim_t2m,2)
    
    
    dfline = data.frame(
      x = 1:240,
      Diff_PR = sdiff_pr,
      Diff_EVA = sdiff_eva,
      Diff_SM = sdiff_sm,
      Diff_VPD = sdiff_vpd,
      Diff_GPP = sdiff_gpp
    )
    
    dflinem = reshape2::melt(dfline,'x')
    source('R/plot_theme.R')
    text_theme = plot_theme(11)
    library(ggsci)
    cols = friendly_pal('ito_seven')
    cols2 = pal_lancet()(6)
    
    alphas = c('Diff_PR' = 0.8,
              'Diff_EVA' = 0.8,
              'Diff_SM' = 0.8,
              'Diff_T2M' = 0.8,
              'Diff_VPD' = 0.8,
              'Diff_GPP' = 1)
    lwds = c('Diff_PR' = 0.7,
            'Diff_EVA' = 0.7,
            'Diff_SM' = 0.7,
            'Diff_T2M' = 0.7,
            'Diff_VPD' = 0.7,
            'Diff_GPP' = 1.3)
    cols = c('Diff_PR' = cols[1],
            'Diff_EVA' = cols[5],
            'Diff_SM' = cols[2],
            'Diff_T2M' = cols[4],
            'Diff_VPD' = cols[6],
            'Diff_GPP' = cols[3])
    cols2 = c('Diff_PR' = cols2[1],
              'Diff_EVA' = cols2[4],
              'Diff_SM' = cols2[6],
              'Diff_T2M' = cols2[2],
              'Diff_VPD' = cols2[5],
              'Diff_GPP' = cols2[3])
    library(ggsci)
    colorblind_tol_palate <- function(
    ){
      cols = c('#332288','#117733','#44AA99','#88CCEE',
              '#DDCC77','#CC6677','#AA4499','#882255')
      return(cols)
    }
    source("R/colorblind_tol_palate.R")
    
    cols3 = colorblind_tol_palate()
    library(scales)
    show_col(cols3)
    cols3 = c('Diff_PR' = cols3[1],
              'Diff_EVA' = cols3[4],
              'Diff_SM' = cols3[5],
              'Diff_T2M' = cols3[6],
              'Diff_VPD' = cols3[8],
              'Diff_GPP' = cols3[2])
    plines = ggplot()+
      geom_line(data = dflinem,
                aes(x = x,y = value,color = variable,
                    alpha = variable,
                    linewidth = variable))+
      #scale_color_lancet()+
      #scale_color_lancet()+
      scale_color_manual(values = cols3)+
      scale_alpha_manual(values = alphas)+
      scale_linewidth_manual(values = lwds)+
      scale_x_continuous(breaks = c(1,110,240),
                        labels = c(2003,2012,2023))+
      scale_y_continuous(breaks= c(-2,-1,0,1,2),
                        #labels = aim_eva,
                        limits = c(-2.5,2.5))+
      theme_bw()+
      text_theme+
      theme(legend.position = 'none',
            axis.line = element_line(color = 'black',
                                    linewidth = 0.5,
                                    linetype = 1,
                                    arrow = arrow(angle = 20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'open')),
            panel.border = element_blank())+
      xlab('Time')+
      ylab('Differences between A and C')
    
    plines+theme(legend.position = 'bottom')
    
    generate_plinex <- function(tmp_aims,colsid,
                                ylab){
      plinex1 = ggplot()+
        #geom_line(data = dfline,
        #          aes(x = x,y = Diff_EVA))+
        #geom_blank()+
        
        scale_y_continuous(breaks= c(-2,-1,0,1,2),
                          labels = tmp_aims,
                          limits = c(-2.5,2.5))+
        scale_x_continuous(breaks= c(2003,2012,2023),
                          #labels = aim_eva,
                          limits = c(2003,2023))+
        theme_bw()+
        text_theme+
        theme(legend.position = 'none',
              axis.line = element_line(color = cols3[colsid],
                                      linewidth = 0.5,
                                      linetype = 1,
                                      arrow = arrow(angle = 20,
                                                    length = unit(0.25,'cm'),
                                                    type = 'open')),
              axis.ticks = element_line(color = cols3[colsid]),
              panel.border = element_blank())+
        xlab('Time')+
        ylab(ylab)
      return(plinex1)
    }
    
    pline1x = generate_plinex(aim_pr,1,'Differences in PR')
    pline2x = generate_plinex(aim_eva,2,'Differences in EVA')
    pline3x = generate_plinex(aim_sm,3,'Differences in SM')
    pline5x = generate_plinex(aim_vpd,5,'Differences in VPD')
    pline6x = generate_plinex(aim_gpp,6,'Differences in GPP')
    
    
    library(cowplot)
    pline_com = plot_grid(pline1x,pline2x,pline3x,
                          #pline4x,
                          pline5x,pline6x,
                          plines,nrow = 1,
                          rel_widths = c(1,1,1,1,1,10),
                          rel_heights = c(1,1,1,1,1,1))
    
    cols3 = colorblind_tol_palate()
    show_col(cols3)
    cols3 = c('Diff_PR' = cols3[1],
              'Diff_EVA' = cols3[4],
              'Diff_SM' = cols3[5],
              'Diff_T2M' = cols3[6],
              'Diff_VPD' = cols3[8],
              'Diff_GPP' = cols3[2])
    cors_diff = data.frame(
      x = c(1:4),
      y = c(cor(sdiff_pr,sdiff_gpp),
            cor(sdiff_eva,sdiff_gpp),
            cor(sdiff_sm,sdiff_gpp),
            #cor(sdiff_t2m,sdiff_gpp),
            cor(sdiff_vpd,sdiff_gpp))
    )
    
    dfp1 = data.frame(
      x = rep(sdiff_gpp,4),
      y = c(sdiff_pr,sdiff_eva,sdiff_sm,sdiff_vpd),
      type = rep(c('Diff_PR',
                  'Diff_EVA',
                  'Diff_SM',
                  'Diff_VPD'),each = 240)
    )
    
    ppoint2 = ggplot()+
      geom_point(data = dfp1,
                aes(x = x,y= y,color = type,
                    shape = type))+
      scale_color_manual(values = cols3)+
      geom_abline(slope = 1,intercept = 0)+
      scale_x_continuous(breaks= c(-2,-1,0,1,2),
                        #labels = aim_eva,
                        limits = c(-2.5,2.5))+
      scale_y_continuous(breaks= c(-2,-1,0,1,2),
                        #labels = aim_eva,
                        limits = c(-2.6,2.5))+
      theme_bw()+
      text_theme+
      theme(legend.position = 'none',
            axis.line = element_line(color = 'black',
                                    linewidth = 0.5,
                                    linetype = 1,
                                    arrow = arrow(angle = 20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'open')),
            panel.border = element_blank())+
      xlab('Time')+
      ylab('Differences between A and C')
    
    library(ggpubr)
    ppoint2_leg = as_ggplot(get_legend(ppoint2+theme(legend.position = 'bottom')+
                                        guides(color = guide_legend(ncol = 1,
                                                                    title = ''),
                                                shape =  guide_legend(ncol = 1,
                                                                      title = ''))))
    
    
    pline_com = plot_grid(
      pline_com,ppoint2,nrow = 1,
      rel_heights = c(1,1),
      rel_widths = c(15,5)
    )
    output = 'main_plot/Figure3/'
    dir.create(output)
    output = paste0(output,'/pline_com3.pdf')
    ggsave(output,pline_com,height = 6.5,
          width  = 22,units = 'cm',dpi = 800)
    
    # compare s
    
    dfp2 = data.frame(
      VPD = c(vpd1,vpd2),
      GPP = c(gpp1,gpp2),
      type = rep(c('System A','System C'),each = 240)
    )
    
    
    ppoint3 = ggplot()+
      geom_point(data = dfp2,
                aes(x = VPD,y= GPP,color = type),
                shape = 1)+
      scale_color_lancet()+
      #scale_color_manual(values = cols3)+
      #geom_abline(slope = 1,intercept = 0)+
      geom_vline(xintercept = 0.93,
                color = 'grey20',
                linetype = 'dashed')+
      scale_x_continuous(breaks= c(0.8,0.93,1))+
      theme_bw()+
      text_theme+
      theme(legend.position = 'none',
            axis.line = element_line(color = 'black',
                                    linewidth = 0.5,
                                    linetype = 1,
                                    arrow = arrow(angle = 20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'open')),
            panel.border = element_blank())+
      xlab('VPD')+
      ylab('GPP')
    ppoint3  
    
    ppoint3_leg = as_ggplot(get_legend(ppoint3+theme(legend.position = 'bottom')+
                                        guides(color = guide_legend(ncol = 1,
                                                                    title = ''),
                                                shape =  guide_legend(ncol = 1,
                                                                      title = ''))))
    
    input_et_gleam = 'data_for_sharing/gleam_et_03_23/gleam_et_03_23.csv'
    et = as.data.frame(fread(input_et_gleam))
  

    dfp_et_vpd = data.frame(
      VPD = c(vpd1,vpd2),
      #T = c(stand_fun(et[,1]),stand_fun(et[,2])),
      T = c(et[,1],et[,2]),
      type = rep(c('System A','System C'),each = 240), 
      shape = 1
    )

    ppoint_et_vpd = ggplot()+
      geom_point(data = dfp_et_vpd,
                aes(x = VPD,y= T,color = type),
                shape = 1)+
      scale_color_lancet()+
      #scale_color_manual(values = cols3)+
      #geom_abline(slope = 1,intercept = 0)+
      geom_vline(xintercept = 0.93,
                color = 'grey20',
                linetype = 'dashed')+
      scale_x_continuous(breaks= c(0.8,0.93,1))+
      #scale_y_continuous(breaks = c(12.5,16.5,20))+
      theme_bw()+
      text_theme+
      theme(legend.position = 'none',
            axis.line = element_line(color = 'black',
                                    linewidth = 0.5,
                                    linetype = 1,
                                    arrow = arrow(angle = 20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'open')),
            panel.border = element_blank())+
      xlab('VPD')+
      ylab('GLEAM T')


    
    # output = 'main_plot/new/Figure3/fig3_journal_1231_mapratio'
    # dir.create(output)
    # output = paste0(output,'/ppoint_gpp_vpd.pdf')
    # ggsave(output,ppoint3,height = 6.5 ,
    #        width  = 22,units = 'cm',dpi = 800)
    
    plines_leg = as_ggplot(get_legend(plines+
                                        theme(legend.position = 'bottom')+
                                        guides(color = guide_legend(nrow = 2,
                                                                    title = ''),
                                              alpha = guide_legend(nrow = 2,
                                                                    title = ''),
                                              linewidth = guide_legend(nrow = 2,
                                                                        title = ''))))
    output = 'main_plot/Figure3/'
    dir.create(output)
    output1 = paste0(output,'/pline_leg.pdf')
    output2= paste0(output,'/ppoint2_leg.pdf')
    output3 = paste0(output,'/ppoint3_leg.pdf')
    
    ggsave(output1,plines_leg,height = 8,
          width  = 10,units = 'cm',dpi = 800)
    
    
    ggsave(output2,ppoint2_leg,height = 8,
          width  = 10,units = 'cm',dpi = 800)
    
    ggsave(output3,ppoint3_leg,height = 8,
          width  = 10,units = 'cm',dpi = 800)
    
    
    # fig3 coorelation betweeen local vapor release and GPP
    
    inputs = paste0('data_for_sharing/Figure3/gross_release_by_source/',
                    c('eua1','eua2','eua3','nam1','nam2'))
    
    region_code = c('eua1','eua2','eua3','nam1','nam2')
    
    stand_trend3 <- function(x){
      if(length(which(is.na(x)))>100){
        x = rep(NA,240)
      }else{
        x[which(is.na(x))] = 0
        x = ts(x,start = c(2000,1),frequency = 12)
        x = decompose(x)$trend
        x = x[-which(is.na(x))]
        #x = (x-mean(x))/sd(x)
      }
      return(x)
    }
    
    calc_diffs <- function(nam1){
      input = 'data_for_sharing/Figure3/aligned_spatial_df_indices'
      input1 = paste0(input,'/twsdf.csv')
      input2 = paste0(input,'/gppdf.csv')
      input3 = paste0(input,'/rootsmdf.csv')
      input4 = paste0(input,'/evadf')
      input5 = paste0(input,'/t2mdf.csv')
      input6 = paste0(input,'/prdf.csv')
      input7 = paste0(input,'/loc.csv')
      input8 = paste0(input,'/vpddec.csv')
      input9 = paste0(input,'/vpdinc.csv')
      
      twsdf = as.data.frame(fread(input1))
      gppdf = as.data.frame(fread(input2))
      rootsmdf = as.data.frame(fread(input3))
      evadf = as.data.frame(fread(input4))
      t2mdf = as.data.frame(fread(input5))
      prdf = as.data.frame(fread(input6))
      loc = as.data.frame(fread(input7))
      longlat1 = paste0(loc[,1],'_',loc[,2])
      
      source('R/stand_trend_fun.R')
      input_increase_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/increase_gpp_cwsi.csv'
      input_decrease_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/decrase_gpp_cwsi.csv'
      
      inc_gpp = as.data.frame(fread(input_increase_gpp_cwsi))
      dec_gpp = as.data.frame(fread(input_decrease_gpp_cwsi))
      
      inc_gpp$long_lat = paste0(inc_gpp[,1]+ 0.125,'_',inc_gpp[,2]+ 0.125)
      dec_gpp$long_lat = paste0(dec_gpp[,1]+ 0.125,'_',dec_gpp[,2]+ 0.125)
      
      inc_gpp = inc_gpp[which(inc_gpp$CWSI<0),]
      dec_gpp = dec_gpp[which(dec_gpp$CWSI<0),]
      
      id1 = which(longlat1 %in% inc_gpp$long_lat)
      id2 = which(longlat1 %in% dec_gpp$long_lat)
      
      #source('R/shp_management.R')
      #nam1 = shp_management('eua2')
      ex_nam1 = extent(nam1)
      
      loc1 = loc[id1,]
      loc2 = loc[id2,]
      id11 = which(loc1[,1]<ex_nam1[2] &
                    loc1[,2]<ex_nam1[4] &
                    loc1[,1]>ex_nam1[1] &
                    loc1[,2]>ex_nam1[3])
      id12 = which(loc2[,1]<ex_nam1[2] &
                    loc2[,2]<ex_nam1[4] &
                    loc2[,1]>ex_nam1[1] &
                    loc2[,2]>ex_nam1[3])
      
      
      loc11 = loc1[id11,]
      loc21 = loc2[id12,]

      gppdf1 = gppdf[id1,][id11,]
      gppdf2 = gppdf[id2,][id12,]

      source('R/calc_area_weighted_average_value_df.R')
      calc_area_weighted_average_value_df <- function(rastdf)
      {
        # rastdf structure
        # multiple columns
        library(ClimProjDiags)
        # rast is a raster of map 
        #rastdf = as.data.frame(rast,xy = T)
        
        lon = rastdf[,1]
        lat = rastdf[,2]
        
        rastdf = rastdf[,-c(1,2)]
        i = 1:ncol(rastdf)
        subfun<-function(i){
          library(ClimProjDiags)
          library(raster)
          tmp = data.frame(
                long = lon,
                lat = lat,
                value = rastdf[,i])
          coordinates(tmp) = ~long+lat
          gridded(tmp) = T
          tmp = raster(tmp)

          tmp = as.data.frame(tmp,xy = T)
          uni_lon = unique(tmp[,1])
          uni_lat = unique(tmp[,2])
          
          value = tmp[,3]
          dim(value) = c(lon = length(uni_lon),
                        lat = length(uni_lat),time = 1)

          a = WeightedMean(value,lon=uni_lon,lat = uni_lat)
          return(a)

        }
        #value = rastdf[,3]
        
        library(doParallel)
        cl = makeCluster(20)
        registerDoParallel(cl)
        retvec = foreach(i=i) %dopar%{
          subfun(i)
        }
        stopCluster(cl)

        a = do.call(c,retvec)  
        
        #w = init(rast,'y')
        #w = cos(w*(pi/180))
        
        #x = rast * w
        #xmean = cellStats(x,sum)/cellStats(w,sum)
        
        return(a)
      
        
        
        
        
        
        
      }
      gppdf1 = calc_area_weighted_average_value_df(cbind(loc11,gppdf1))
      gppdf2 = calc_area_weighted_average_value_df(cbind(loc21,gppdf2))
      
      #gppdf1 = apply(gppdf1,2,mean)
      #gppdf2 = apply(gppdf2,2,mean)
      
      smdf1 = rootsmdf[id1,][id11,]
      smdf2 = rootsmdf[id2,][id12,]
      
      smdf1 = calc_area_weighted_average_value_df(cbind(loc11,smdf1))
      smdf2 = calc_area_weighted_average_value_df(cbind(loc21,smdf2))
      
      #smdf1 = apply(smdf1,2,mean)
      #smdf2 = apply(smdf2,2,mean)
      
      tws1 = twsdf[id1,][id11,]
      tws2 = twsdf[id2,][id12,]
      
      pr1 = prdf[id1,][id11,]
      pr2 = prdf[id2,][id12,]
      
      spr1 = stand_trend_fun(apply(pr1,2,mean,na.rm = T))
      spr2 = stand_trend_fun(apply(pr2,2,mean,na.rm = T))
      
      evadf1 = evadf[id1,][id11,]
      evadf2 = evadf[id2,][id12,]

      evadf1 = calc_area_weighted_average_value_df(cbind(loc11,evadf1))
      evadf2 = calc_area_weighted_average_value_df(cbind(loc21,evadf2))

      #evadf1 = apply(evadf[id1,][id11,],2,mean)
      #evadf2 = apply(evadf[id2,][id12,],2,mean)
      diff_eva = stand_trend2(evadf1-evadf2)
      
      t2mdf1 = t2mdf[id1,][id11,]
      t2mdf2 = t2mdf[id2,][id12,]  
      
      t2mdf1 = calc_area_weighted_average_value_df(cbind(loc11,t2mdf1))
      t2mdf2 = calc_area_weighted_average_value_df(cbind(loc21,t2mdf2))
      #t2mdf1 = apply(t2mdf1,2,mean)
      #t2mdf2 = apply(t2mdf2,2,mean)
      
      t2mdf1 = stand_trend2(t2mdf1)
      t2mdf2 = stand_trend2(t2mdf2)
      
      evadf1 = evadf[id1,][id11,]
      evadf2 = evadf[id2,][id12,]

      evadf1 = calc_area_weighted_average_value_df(cbind(loc11,evadf1))
      evadf2 = calc_area_weighted_average_value_df(cbind(loc21,evadf2))

      #evadf1 = apply(evadf[id1,][id11,],2,mean)
      #evadf2 = apply(evadf[id2,][id12,],2,mean)
      
      prdf1 = prdf[id1,][id11,]
      prdf2 = prdf[id2,][id12,]
      prfull = rbind(prdf1,prdf2)
      locfull = rbind(loc11,loc21)

      prdf1 = calc_area_weighted_average_value_df(cbind(loc11,prdf1))
      prdf2 = calc_area_weighted_average_value_df(cbind(loc21,prdf2))
      prfull = calc_area_weighted_average_value_df(cbind(locfull,prfull))
      
      #prdf1 = apply(prdf[id1,][id11,],2,mean)
      #prdf2 = apply(prdf[id2,][id12,],2,mean)
      #prfull = apply(rbind(prdf[id1,][id11,],
      #                     prdf[id2,][id12,]),2,mean)
      
      sprdf1 = stand_trend2(prdf1)
      sprdf2 = stand_trend2(prdf2)
      sprfull = stand_trend2(prfull)
      
      vpdf1 = as.data.frame(fread(paste0(input,'/vpdinc.csv')))
      vpdf2 = as.data.frame(fread(paste0(input,'/vpddec.csv')))
      vpdf1 = vpdf1[id11,]
      vpdf2 = vpdf2[id12,]
      vpdf1 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc11,vpdf1)))
      vpdf2 = stand_trend2(calc_area_weighted_average_value_df(cbind(loc21,vpdf2)))
      
      #vpdf1 = stand_trend2(apply(vpdf1[id11,],2,mean))
      #vpdf2 = stand_trend2(apply(vpdf2[id12,],2,mean))
      
      diff_pr = stand_trend2(prdf1-prdf2)
      diff_eva = stand_trend2(evadf1-evadf2)
      diff_gpp = stand_trend2(gppdf1-gppdf2)
      diff_sm = stand_trend2(smdf1-smdf2)
      diff_vpd = stand_fun(vpdf2 - vpdf1)
      diff_t2m = stand_fun(t2mdf2-t2mdf1)
      return(data.frame(diff_pr,diff_gpp,diff_sm,diff_vpd,diff_t2m,diff_eva))
    }
    source('R/shp_management.R')
    nam1 = shp_management('nam1') # long/lat extent: -122.5,-96,20,40 in North America dryland
    nam2 = shp_management('nam2') # long/lat extent: -125,-96,40,60 in North America dryland
    eua1 = shp_management('eua1') # long/lat extent: -17,30,20,54 in North Africa and Eurasia dryland
    eua2 = shp_management('eua2') # long/lat extent: 30,80,20,60 in North Africa and Eurasia dryland
    eua3 = shp_management('eua3') # long/lat extent: 80,129,20,60 in North Africa and Eurasia dryland
    
    diff_nam1 = calc_diffs(nam1)
    diff_nam2 = calc_diffs(nam2)
    diff_eua1 = calc_diffs(eua1)
    diff_eua2 = calc_diffs(eua2)
    diff_eua3 = calc_diffs(eua3)
    
    diffs2 = list(diff_eua1,
                  diff_eua2,
                  diff_eua3,
                  diff_nam1,
                  diff_nam2)
    
    
    sumbox = 1
    indiffbox = 1
    for(i in 1:5){
      print(i)
      inputid1 = paste0(list.files(paste0('data_for_sharing/Figure3/first_particle_location/',toupper(region_code[i]),
                                          '_vapor'),full.names = T)[1],'/df_first_ocean')
      inputid2 = paste0(list.files(paste0('data_for_sharing/Figure3/first_particle_location/',toupper(region_code[i]),
                                          '_vapor'),full.names = T)[1],'/df_first_land')
      
      ocenames = do.call(c,strsplit(list.files(inputid1),'.csv'))
      connames = do.call(c,strsplit(list.files(inputid2),'.csv'))
      sources = c(ocenames,connames)
      
      tmp1 = as.data.frame(fread(list.files(inputs[i],full.names = T)[1]))*-1
      tmp2 = as.data.frame(fread(list.files(inputs[i],full.names = T)[2]))*-1
      
      
      tmp1 = apply(tmp1,2,fill_the_gap)
      tmp2 = apply(tmp2,2,fill_the_gap)
      
      
      
      #tmp1 = apply(tmp1,2,stand_trend3)
      #tmp2 = apply(tmp2,2,stand_trend3)
      diffs = tmp1-tmp2
      
      inid = which(sources == region_code[i])
      
      indiffs = diffs[,inid]
      indiffbox= cbind(indiffbox,indiffs)
      sumbox = cbind(sumbox,apply(diffs,1,sum,na.rm = T))
      
    }
    sumbox = sumbox[,-1]
    indiffbox = indiffbox[,-1]
    
    
    
    
    diff_gpps = cbind(diff_eua1[,2],diff_eua2[,2],
                      diff_eua3[,2],diff_nam1[,2],diff_nam2[,2])
    diff_pr = cbind(diff_eua1[,1],diff_eua2[,1],
                    diff_eua3[,1],diff_nam1[,1],diff_nam2[,1])
    diff_sm = cbind(diff_eua1[,3],diff_eua2[,3],
                    diff_eua3[,3],diff_nam1[,3],diff_nam2[,3])
    
    
    calc_stat <- function(df){
      tmpmean = apply(df,1,mean)
      tmpmin = apply(df,1,min)
      tmpmax = apply(df,1,max)
      return(data.frame(
        mean = tmpmean,
        min = tmpmin,
        max = tmpmax
      ))
    }
    diff_gpps_mean = calc_stat(diff_gpps)
    diff_pr_mean = apply(diff_pr,1,mean)
    diff_sm_mean = apply(diff_sm,1,mean)
    vapor_release = apply(indiffbox,1,mean)
    tvapor_release = apply(sumbox,1,mean)
    
    figsubs_net_release_diff_by_heights_whole <- function(
      fontsize = 12,
      textsize = 4
    ){
      
      region_code = c('nam1','nam2','eua1','eua2','eua3')
      input = 'data_for_sharing/Figure3/net_release_at_target_by_heights'
      input = paste0(input,'/',region_code)
      input1 = paste0(input,'/net_release_',region_code,'_by_heights.csv')
      
      library(data.table)
      diffs= lapply(lapply(input1,fread),as.data.frame)
      source('R/stand_trend2.R')
      source("R/stand_fun.R")
      calc_diffs <- function(nam1){
        input = 'data_for_sharing/Figure3/aligned_spatial_df_indices'
        input1 = paste0(input,'/twsdf.csv')
        input2 = paste0(input,'/gppdf.csv')
        input3 = paste0(input,'/rootsmdf.csv')
        input4 = paste0(input,'/evadf')
        input5 = paste0(input,'/t2mdf.csv')
        input6 = paste0(input,'/prdf.csv')
        input7 = paste0(input,'/loc.csv')
        input8 = paste0(input,'/vpddec.csv')
        input9 = paste0(input,'/vpdinc.csv')
        
        
        twsdf = as.data.frame(fread(input1))
        gppdf = as.data.frame(fread(input2))
        rootsmdf = as.data.frame(fread(input3))
        evadf = as.data.frame(fread(input4))
        t2mdf = as.data.frame(fread(input5))
        prdf = as.data.frame(fread(input6))
        loc = as.data.frame(fread(input7))
        longlat1 = paste0(loc[,1],'_',loc[,2])
        
        source('R/stand_trend_fun.R')
        input_increase_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/increase_gpp_cwsi.csv'
        input_decrease_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/decrase_gpp_cwsi.csv'
        
        inc_gpp = as.data.frame(fread(input_increase_gpp_cwsi))
        dec_gpp = as.data.frame(fread(input_decrease_gpp_cwsi))
        
        inc_gpp$long_lat = paste0(inc_gpp[,1]+ 0.125,'_',inc_gpp[,2]+ 0.125)
        dec_gpp$long_lat = paste0(dec_gpp[,1]+ 0.125,'_',dec_gpp[,2]+ 0.125)
        
        inc_gpp = inc_gpp[which(inc_gpp$CWSI<0),]
        dec_gpp = dec_gpp[which(dec_gpp$CWSI<0),]
        
        id1 = which(longlat1 %in% inc_gpp$long_lat)
        id2 = which(longlat1 %in% dec_gpp$long_lat)
        
        #source('R/shp_management.R')
        #nam1 = shp_management('eua2')
        ex_nam1 = extent(nam1)
        
        loc1 = loc[id1,]
        loc2 = loc[id2,]
        id11 = which(loc1[,1]<ex_nam1[2] &
                      loc1[,2]<ex_nam1[4] &
                      loc1[,1]>ex_nam1[1] &
                      loc1[,2]>ex_nam1[3])
        id12 = which(loc2[,1]<ex_nam1[2] &
                      loc2[,2]<ex_nam1[4] &
                      loc2[,1]>ex_nam1[1] &
                      loc2[,2]>ex_nam1[3])
        
        loc11 = loc1[id11,]
        loc21 = loc2[id12,]
        
        gppdf1 = gppdf[id1,][id11,]
        gppdf2 = gppdf[id2,][id12,]
        calc_area_weighted_average_value_df <- function(rastdf)
        {
          # rastdf structure
          # multiple columns
          library(ClimProjDiags)
          # rast is a raster of map 
          #rastdf = as.data.frame(rast,xy = T)
          
          lon = rastdf[,1]
          lat = rastdf[,2]
          
          rastdf = rastdf[,-c(1,2)]
          i = 1:ncol(rastdf)
          subfun<-function(i){
            library(ClimProjDiags)
            library(raster)
            tmp = data.frame(
                  long = lon,
                  lat = lat,
                  value = rastdf[,i])
            coordinates(tmp) = ~long+lat
            gridded(tmp) = T
            tmp = raster(tmp)

            tmp = as.data.frame(tmp,xy = T)
            uni_lon = unique(tmp[,1])
            uni_lat = unique(tmp[,2])
            
            value = tmp[,3]
            dim(value) = c(lon = length(uni_lon),
                          lat = length(uni_lat),time = 1)

            a = WeightedMean(value,lon=uni_lon,lat = uni_lat)
            return(a)

          }
          #value = rastdf[,3]
          
          library(doParallel)
          cl = makeCluster(20)
          registerDoParallel(cl)
          retvec = foreach(i=i) %dopar%{
            subfun(i)
          }
          stopCluster(cl)

          a = do.call(c,retvec)  
          
          #w = init(rast,'y')
          #w = cos(w*(pi/180))
          
          #x = rast * w
          #xmean = cellStats(x,sum)/cellStats(w,sum)
          
          return(a)
        
        }
        source('R/calc_area_weighted_average_value_df.R')
        gppdf1 = calc_area_weighted_average_value_df(cbind(loc11,gppdf1))
        gppdf2 = calc_area_weighted_average_value_df(cbind(loc21,gppdf2))

        #gppdf1 = apply(gppdf1,2,mean)
        #gppdf2 = apply(gppdf2,2,mean)
        smdf1 = rootsmdf[id1,][id11,]
        smdf2 = rootsmdf[id2,][id12,]

        smdf1 = calc_area_weighted_average_value_df(cbind(loc11,smdf1))
        smdf2 = calc_area_weighted_average_value_df(cbind(loc21,smdf2))
        #smdf1 = apply(smdf1,2,mean)
        #smdf2 = apply(smdf2,2,mean)
        tws1 = twsdf[id1,][id11,]
        tws2 = twsdf[id2,][id12,]
        pr1 = prdf[id1,][id11,]
        pr2 = prdf[id2,][id12,]
        spr1 = stand_trend_fun(apply(pr1,2,mean,na.rm = T))
        spr2 = stand_trend_fun(apply(pr2,2,mean,na.rm = T))
        
        evadf1 = evadf[id1,][id11,]
        evadf2 = evadf[id2,][id12,]
        
        evadf1 = calc_area_weighted_average_value_df(cbind(loc11,evadf1))
        evadf2 = calc_area_weighted_average_value_df(cbind(loc21,evadf2))
        #evadf1 = apply(evadf[id1,][id11,],2,mean)
        #evadf2 = apply(evadf[id2,][id12,],2,mean)
        diff_eva = stand_trend2(evadf1-evadf2)
        
        t2mdf1 = t2mdf[id1,][id11,]
        t2mdf2 = t2mdf[id2,][id12,]  
        
        t2mdf1 = calc_area_weighted_average_value_df(cbind(loc11,t2mdf1))
        t2mdf2 = calc_area_weighted_average_value_df(cbind(loc21,t2mdf2))

        #t2mdf1 = apply(t2mdf1,2,mean)
        #t2mdf2 = apply(t2mdf2,2,mean)
        
        t2mdf1 = stand_trend2(t2mdf1)
        t2mdf2 = stand_trend2(t2mdf2)
        
        evadf1 = evadf[id1,][id11,]
        evadf2 = evadf[id2,][id12,]
        evadf1 = calc_area_weighted_average_value_df(cbind(loc11,evadf1))
        evadf2 = calc_area_weighted_average_value_df(cbind(loc21,evadf2))

        #evadf1 = apply(evadf[id1,][id11,],2,mean)
        #evadf2 = apply(evadf[id2,][id12,],2,mean)
        
        prdf1 = prdf[id1,][id11,]
        prdf2 = prdf[id2,][id12,]
        prfull = rbind(prdf1,prdf2)
        locfull = rbind(loc11,loc21)

        prdf1 = calc_area_weighted_average_value_df(cbind(loc11,prdf1))
        prdf2 = calc_area_weighted_average_value_df(cbind(loc21,prdf2))
        prfull = calc_area_weighted_average_value_df(cbind(locfull,prfull))
        #prdf1 = apply(prdf[id1,][id11,],2,mean)
        #prdf2 = apply(prdf[id2,][id12,],2,mean)
        #prfull = apply(rbind(prdf[id1,][id11,],
        #                     prdf[id2,][id12,]),2,mean)
        
        sprdf1 = stand_trend2(prdf1)
        sprdf2 = stand_trend2(prdf2)
        sprfull = stand_trend2(prfull)
        vpdf1 = as.data.frame(fread(paste0(input,'/vpdinc.csv')))
        vpdf2 = as.data.frame(fread(paste0(input,'/vpddec.csv')))
        
        vpdf1 = vpdf1[id11,]
        vpdf2 = vpdf2[id12,]
        vpdf1 = calc_area_weighted_average_value_df(cbind(loc11,vpdf1))
        vpdf2 = calc_area_weighted_average_value_df(cbind(loc21,vpdf2))
        
        vpdf1 = stand_trend2(vpdf1)
        vpdf2 = stand_trend2(vpdf2)
        
        #vpdf1 = stand_trend2(apply(vpdf1[id11,],2,mean))
        #vpdf2 = stand_trend2(apply(vpdf2[id12,],2,mean))
        
        diff_pr = stand_trend2(prdf1-prdf2)
        diff_gpp = stand_trend2(gppdf1-gppdf2)
        diff_sm = stand_trend2(smdf1-smdf2)
        diff_vpd = stand_fun(vpdf2 - vpdf1)
        diff_t2m = stand_fun(t2mdf2-t2mdf1)
        return(data.frame(diff_pr,diff_gpp,diff_sm,diff_vpd,diff_t2m,diff_eva))
      }
      source('R/shp_management.R')
      nam1 = shp_management('nam1')
      nam2 = shp_management('nam2')
      eua1 = shp_management('eua1')
      eua2 = shp_management('eua2')
      eua3 = shp_management('eua3')
      
      diff_nam1 = calc_diffs(nam1)
      diff_nam2 = calc_diffs(nam2)
      diff_eua1 = calc_diffs(eua1)
      diff_eua2 = calc_diffs(eua2)
      diff_eua3 = calc_diffs(eua3)
      
      diff_gpp = cbind(diff_nam1$diff_gpp,
                      diff_nam2$diff_gpp,
                      diff_eua1$diff_gpp,
                      diff_eua2$diff_gpp,
                      diff_eua3$diff_gpp)
      diff_vpd = cbind(diff_nam1$diff_vpd,
                      diff_nam2$diff_vpd,
                      diff_eua1$diff_vpd,
                      diff_eua2$diff_vpd,
                      diff_eua3$diff_vpd)
      diff_pr = cbind(diff_nam1$diff_pr,
                      diff_nam2$diff_pr,
                      diff_eua1$diff_pr,
                      diff_eua2$diff_pr,
                      diff_eua3$diff_pr)
      diff_eva = cbind(diff_nam1$diff_eva,
                      diff_nam2$diff_eva,
                      diff_eua1$diff_eva,
                      diff_eua2$diff_eva,
                      diff_eua3$diff_eva)
      
      heights = c(0,seq(10,100,10),seq(200,1900,100))
      heighte = c(seq(10,100,10),seq(200,2000,100))
      
      line_legend_location= list(
        theme(legend.position = c(0.8,0.2),
              legend.title = element_blank()),# nam1
        theme(legend.position = c(0.2,0.8),
              legend.title = element_blank()),# nam2,
        theme(legend.position = c(0.2,0.8),
              legend.title = element_blank()),# eua1,
        theme(legend.position = c(0.8,0.15),
              legend.title = element_blank()),# eua2,
        theme(legend.position = c(0.5,0.8),
              legend.title = element_blank()) # eua3
      )
      
      diff_net_relebox = 1
      
      for(i in 1:length(region_code)){
        tmpdiff = diffs[[i]]
        tmp1 = cor(tmpdiff,diff_gpp[,i])
        tmp2 = cor(tmpdiff,diff_vpd[,i])
        tmp3 = cor(tmpdiff,diff_pr[,i])
        tmp4 = cor(tmpdiff,diff_eva[,i])
        
        tmpid1 = which.max(tmp1)
        tmpid2 = which.max(tmp2)
        tmpid3 = which.max(tmp3)
        tmpid4 = which.max(tmp4)
        tmpids = c(tmpid1,tmpid2,tmpid3,tmpid4)
        
        
        seldiff = tmpdiff[,unique(c(tmpid2,tmpid4))]
        tmpvpd = diff_vpd[,i]
        tmpeva = diff_eva[,i]
        diff_net_relebox = cbind(diff_net_relebox,seldiff)
        
      }
      diff_net_relebox = diff_net_relebox[,-1]
      
      mean_diff = apply(diff_net_relebox,1,mean)
      mean_vpd = apply(diff_vpd,1,mean)
      mean_eva = apply(diff_eva,1,mean)
      
      return(data.frame(
        Diff_vapor = mean_diff,
        Diff_vpd = mean_vpd,
        Diff_eva = mean_eva
      ))
      
    }

    #source("R/figsubs_net_release_diff_by_heights_whole.R")
    
    net_release_vpd_eva = figsubs_net_release_diff_by_heights_whole()
    
    # dfpoint3= data.frame(
    #   x = rep(stand_fun(vapor_release),2),
    #   y = c(stand_fun(diff_gpps_mean[,1]),
    #         stand_fun(diff_pr_mean)),
    #   type = rep(c('GPP','PR'),each = 240)
    # )
    
    
    dfpoint3= data.frame(
      x = rep(stand_fun(net_release_vpd_eva[,1]),2),
      y = c(stand_fun(net_release_vpd_eva[,2]),
            stand_fun(net_release_vpd_eva[,3])),
      type = rep(c('VPD','EVA'),each = 240)
    )
    
    cor1 = cor(net_release_vpd_eva[,1],
              net_release_vpd_eva[,2])
    cor2 = cor(net_release_vpd_eva[,1],
              net_release_vpd_eva[,3])
    
    
    pv1 = cor.test(net_release_vpd_eva[,1],
              net_release_vpd_eva[,2])$p.value
    pv2 = cor.test(net_release_vpd_eva[,1],
              net_release_vpd_eva[,3])$p.value
    
    dftext = data.frame(
      x = c(-2),
      y = c(-2.2,-2.8),
      cor = c(cor1,cor2)
    )
    
    dftext$label = paste0(
      c('r: VPD vs. vapor release=',
        'r: EVA vs. vapor release='
      ),
      round(dftext$cor,1),
      '(p<0.001)')
    
    
    
    cols3 = colorblind_tol_palate()
    show_col(cols3)
    cols3 = c('VPD' = cols3[1],
              'EVA' = cols3[2])
    shape = c('VPD' = 17,
              'EVA' = 116)
    
    text_theme = plot_theme(11)
    
    ppoint4 = ggplot()+
      geom_point(data = dfpoint3,
                aes(x = x,y= y,color = type,
                    shape = type))+
      geom_text(data = dftext,
                aes(x = x,y = y,label = label),
                size = textsize,
                color = 'black',hjust = 0)+
      scale_color_manual(values = cols3)+
      geom_abline(slope = 1,intercept = 0)+
      scale_x_continuous(breaks= c(-2,-1,0,1,2))+
      #labels = aim_eva,
      #limits = c(-2.5,2.5))+
      scale_y_continuous(breaks= c(-2,-1,0,1,2))+
      #labels = aim_eva,
      #limits = c(-2.5,2.5))+
      theme_bw()+
      text_theme+
      theme(legend.position = 'none',
            axis.line = element_line(color = 'black',
                                    linewidth = 0.5,
                                    linetype = 1,
                                    arrow = arrow(angle = 20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'open')),
            panel.border = element_blank())+
      xlab('Net water vapor releases difference at specific heights')+
      ylab('Differences between A and C')
    
    ppoint4_leg = as_ggplot(get_legend(ppoint4+theme(legend.position = 'bottom')+
                                        guides(color = guide_legend(ncol = 1,
                                                                    title = ''),
                                                shape =  guide_legend(ncol = 1,
                                                                      title = ''))))
    ppoints = plot_grid(ppoint3,
                        ppoint_et_vpd,
                        ppoint4,
                        nrow = 1,
                        rel_heights = c(1,1,1),
                        rel_widths = c(1,1,1))
    
    # ppoints = plot_grid(ppoint4,
    #                     ppoint3,
    #                     nrow = 1,
    #                     rel_heights = c(1,1),
    #                     rel_widths = c(1,1))
    
    output = 'main_plot/Figure3/'
    dir.create(output)
    output1 = paste0(output,'/ppoint4_leg.pdf')
    output2= paste0(output,'/ppoint34.pdf')
    
    ggsave(output2,ppoints,height = 8,
          width  = 22,units = 'cm',dpi = 800)
    
    
    ggsave(output1,ppoint4_leg,height = 8,
          width  = 22,units = 'cm',dpi = 800)
  
  }
  
}