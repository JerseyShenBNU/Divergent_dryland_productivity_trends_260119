main_figure1<- function(
){
  
  fontsize = 12
  textsize = 3.5
  source('R/plot_theme.R')
  
  plot_theme <-function(fontsize = 12){
  
    library(ggplot2)
    text_theme = theme(
      axis.text = element_text(size = fontsize,
                              color = 'black'),
      axis.text.y = element_text(angle = 90,
                                hjust = 0.5),
      axis.title =  element_text(size = fontsize,
                                color = 'black',
                                face = 'bold'),
      legend.text =  element_text(size = fontsize,
                                  color = 'black'),
      legend.title =  element_text(size = fontsize,
                                  color = 'black',
                                  face = 'bold'),
      strip.text =  element_text(size = fontsize,
                                color = 'black'),
      panel.grid = element_blank()
      #plot.background = elemen(),
      #panel.background = element_blank()
    )
    
    return(text_theme)
    
  }
  text_theme = plot_theme(fontsize)
  
  calc_area_weighted_average_value <- function(rast){
    library(ClimProjDiags)
    # rast is a raster of map 
    rastdf = as.data.frame(rast,xy = T)
    
    
    uni_lon = unique(rastdf[,1])
    uni_lat = unique(rastdf[,2])
    
    
    value = rastdf[,3]
    dim(value) = c(lon = length(uni_lon),lat = length(uni_lat),time = 1)
    
    
    a = WeightedMean(value,lon=uni_lon,lat = uni_lat)
    
    return(a)
  }

  # line plot 
  # calc gpp mean 
  calc_gpp_tws_sm_mean <- function(){
    source('R/data_management.R')
    source('R/shp_management.R')
    source("R/calc_area_weighted_average_value.R")
    dryland = shp_management('dryland')
    
    gpp = data_management('resampled_gpp')
    gpp = mask(crop(gpp,dryland),dryland)
    
    tws1 = data_management('grace_rl06_2312')
    tws1 = mask(crop(tws1,dryland),dryland)
    
    tws2 = data_management('smap_filled_tws_03_23')
    tws2 = mask(crop(tws2,dryland),dryland)
    
    tws1 = do.call(c,lapply(as.list(tws1),calc_area_weighted_average_value))
    tws2 = do.call(c,lapply(as.list(tws2),calc_area_weighted_average_value))
    gpp = do.call(c,lapply(as.list(gpp),calc_area_weighted_average_value))
    
    
    stand_trend_fun <- function(x){
      if(is.na(mean(x))){
        x = rep(NA,240)
      }else{
        x = ts(x,start = c(2000,1),frequency = 12)
        x = decompose(x)$trend
        x = x[-which(is.na(x))]
        x = (x-mean(x))/sd(x)
      }
      
      return(x)
    }
    
    
    
    stws1 = stand_trend_fun(tws1)
    stws2 = stand_trend_fun(tws2)
    sgpp = stand_trend_fun(gpp)
    
    # calc_sm 
    library(ncdf4)
    input = '/media/jersey/42C4-C772/Data/gldas_month_soil_moisture_00_23/'
    input = list.files(input,full.names = T)
    
    var = names(nc_open(input[1])$var)
    root_sm = stack(input,varname = var[29])
    
    root_sm = mask(crop(root_sm,dryland),dryland)
    root_sm = do.call(c,lapply(as.list(root_sm),
                               cellStats,
                               mean,na.rm = T))
    date = seq(as.Date('2000-01-01'),as.Date('2023-12-01'),'1 month')
    loc1 = which(date == '2003-01-01')
    loc2 = which(date == '2023-12-01')
    root_sm = root_sm[loc1:loc2]
    root_sm = stand_trend_fun(root_sm)
    
    df = data.frame(
      time = 1:240,
      TWS = stws1,
      GPP = sgpp,
      RSM = root_sm
    )  
    
    output = 'main_plot_output/Figure1_1120'
    dir.create(output)
    output = paste0(output,'/fig1_line_oritws.csv')
    fwrite(df,output)
  }
  #calc_gpp_tws_sm_mean()
  input = 'data_for_sharing/Figure1/fig1_line.csv'
  dfline = as.data.frame(fread(input))  
  dfline = data.frame(
    time = dfline$time,
    TWS = dfline$TWS,
    #RSM = dfline$RSM, # root soil moisture
    GPP = dfline$GPP
  )
  dflinem = reshape2::melt(dfline,'time')  

  library(ggsci)
  cols = pal_lancet()(9)
  cols = c('TWS'= cols[1],
           #'RSM'= cols[4],
           'GPP' = cols[7])
  lwd =  c('TWS'= 1.2,
           #'RSM'= 1,
           'GPP' = 1.2)
  
  dfpoint2 = data.frame(
    x = rep(c(1,240),2),
    y = c(dfline$TWS[c(1,240)],
          dfline$GPP[c(1,240)]),
    variable = rep(c("TWS","GPP"),each = 2)
  )
  pline = ggplot()+
    geom_vline(xintercept = c(1,110,240),
               linewidth= 0.5,
               color = 'grey',
               linetype = 'dashed')+
    geom_line(data = dflinem,
              aes(x = time,y = value,
                  color = variable,
                  linewidth = variable))+
    geom_point(data = dfpoint2,
               aes(x = x,y = y,color = variable),
               size = 2)+
    geom_point(data = dfpoint2,
               aes(x = x,y = y,color = variable),
               size = 4.5,
               shape = 1)+
    scale_color_manual(values = cols)+
    scale_linewidth_manual(values = lwd)+
    theme_bw()+
    text_theme+
    guides(color = guide_legend(nrow = 1,
                                title = '(a) Temporal variations in dryland water resources and productivity',
                                title.position = 'top'),
           linewidth = guide_legend(nrow = 1,
                                    
                                    title = '(a) Temporal variations in dryland water resources and productivity',
                                    title.position = 'top'))+
    theme(legend.position = 'bottom')+
    scale_x_continuous(breaks = c(1,110,240),
                       labels = c(c(2003,2012,2023)))+
    xlab('Time')+
    ylab('Standardized indices')
  pline
  library(ggpubr)
  pline_leg = as_ggplot(get_legend(pline))
  
  pline = pline+theme(legend.position = 'none')
  
  # pvar 
  calc_var <- function(index,change_time,x= 1){
    
    sid = change_time[1:2]
    eid = change_time[2:3]
    varbox = 1
    ys = 1
    for(i in 1:length(sid)){
      tmp1 = index[sid[i]]
      tmp2 = index[eid[i]]
      tmpvar = (tmp2-tmp1)/6
      varbox = c(varbox,tmpvar)
      ys = c(ys,mean(c(tmp1,tmp2)))
    }
    varbox = varbox[-1]
    ys = ys[-1]
    
    ret = data.frame(
      x = x,
      y = ys,
      var = paste0(round(varbox*100))
    )
    
    ret$label = paste0(ret$var,'%')
    ret$label[which(ret$var>0)] = paste0('+',ret$label[which(ret$var>0)] )
    
    return(ret)
  }
  
  var_tws = calc_var(dfline$TWS,c(1,240),1-0.15)
  var_gpp = calc_var(dfline$GPP,c(1,240),2-0.15)

  var_tws = var_tws[1,]
  var_gpp = var_gpp[1,]
  
  dfpoint = data.frame(
    x = rep(c(1,2),each = 2),
    y = c(dfline$TWS[c(1,240)],
          dfline$GPP[c(1,240)]),
    col = rep(c("TWS",'GPP'),each = 2)
  ) 
  
  dfsegs = data.frame(
    x = rep(c(1,2),each = 1),
    y = c(dfline$TWS[c(1)],
          dfline$GPP[c(1)]),
    yend = c(dfline$TWS[c(240)],
             dfline$GPP[c(240)])
  )
  
  
  dfsegsr = data.frame(
    x = rep(c(1,2),each = 1),
    y = c(dfline$TWS[c(1)],
          dfline$GPP[c(1)]),
    yend = c(dfline$TWS[c(240)],
             dfline$GPP[c(240)])
  )
  #dfsegsr = dfsegsr[-3,]
  
  
  dfh = data.frame(
    x = rep(c(1,2),each = 2)-0.15,
    xend = rep(c(1,2),each = 2)+0.15,
    y = c(dfline$TWS[c(1,240)],
          dfline$GPP[c(1,240)])
  )
  
  dfcor = data.frame(
    x = 1.5,
    y = 1.85,
    label = round(cor(dfline$TWS,dfline$GPP),1)
  )
  
  dfh2 = data.frame(
    x = 1,
    xend = 2,
    y = 1.7
  )
  dfseg2 = data.frame(
    x = c(1,2),
    y = c(1.7)+0.1,
    yend = c(1.7)-0.1
  )
  
  dfyear_label = data.frame(
    x = dfh$x - 0.2,
    y = dfh$y,
    label = rep(c(2003,2023),2)
  )
  dfyear_label2 = dfyear_label[4:5,]
  dfyear_label = dfyear_label[-c(4,5),]
  
  p2 = ggplot()+
    geom_point(data = dfpoint,
               aes(x = x,y = y,color = col),
               size = 2)+
    geom_point(data = dfpoint,
               aes(x = x,y = y,color = col),
               size = 4.5,
               shape = 1)+
    geom_segment(data = dfsegsr,
                 aes(x = x,y = y,xend = x,yend = yend),
                 linewidth = 0.5,
                 color = 'black',
                 arrow = arrow(20,unit(0.4,'cm'),type = 'open'))+
    geom_segment(data = dfsegs,
                 aes(x = x,y = y,xend = x,yend = yend),
                 linewidth = 0.5,
                 color = 'black')+
    geom_segment(data = dfh,
                 aes(x = x,y = y,xend = xend,yend = y),
                 linewidth = 0.5,
                 color = 'black')+
    geom_text(data = var_gpp[1,],
              aes(x = x,y =y,label = label ),
              size = textsize,
              color = 'black',
              angle = 90,hjust = 0.5)+
    geom_text(data = var_tws,
              aes(x = x,y =y,label = label ),
              size = textsize,
              color = 'black',
              angle = 90,hjust = 0.5)+
    geom_segment(data = dfseg2,
                 aes(x = x,y = y,xend = x,yend = yend),
                 linewidth = 0.5,
                 color = 'black')+
    geom_segment(data = dfh2,
                 aes(x = x,y = y,xend = xend,yend = y),
                 linewidth = 0.5,
                 color = 'black')+
    geom_text(data = dfcor,
              aes(x = x,y =y,label = label ),
              size = textsize,
              color = 'black',hjust = 0.5)+
    scale_color_manual(values = cols)+
    #geom_text(data = dfyear_label,
    #          aes(x = x,y =y,label = label ),
    #          size = textsize,
    #          color = 'black',
    #          hjust = 0.5)+
    theme_bw()+
    text_theme+
    guides(color = guide_legend(title = '(a-b)',
                                nrow = 1,
                                title.position = 'top'))+
    scale_x_continuous(breaks = c(1,2),
                       limits = c(0.5,2.5),
                       labels = c('TWS','GPP'))+
    xlab("Standardized indices")+
    ylab('Temporal variations')
  library(ggpubr)
  p2_leg = as_ggplot(get_legend(p2))
  p2 = p2 + theme(legend.position = 'none')
  
  
  p21 = ggplot()+
    geom_point(data = dfpoint[4:5,],
               aes(x = x,y = y,color = col),
               size = 2)+
    geom_point(data = dfpoint[4:5,],
               aes(x = x,y = y,color = col),
               size = 4.5,
               shape = 1)+
    geom_segment(data = dfsegs[3,],
                 aes(x = x,y = y,xend = x,yend = yend),
                 linewidth = 0.5,
                 color = 'black',
                 arrow = arrow(20,unit(0.4,'cm'),type = 'open'))+
    geom_segment(data = dfh[4:5,],
                 aes(x = x+0.05,y = y,xend = xend-0.05,yend = y),
                 linewidth = 0.5,
                 color = 'black')+
    geom_text(data = var_gpp[1,],
              aes(x = x,y =y,label = label ),
              size = textsize,
              color = 'black',
              angle = 90,hjust = 0.5)+
    #geom_text(data = dfyear_label2,
    #           aes(x = x+0.6,y =y,label = label ),
    #           size = textsize,
    #           color = 'black',
    #           hjust = 0.5)+
    scale_color_manual(values = cols)+
    scale_y_continuous(limits = c(-1.21,-1.13))+
    scale_x_continuous(limits = c(1.5,2.5))+
    
    theme_void()+
    #text_theme+
    theme(legend.position = 'none')+
    xlab("Standardized indices")+
    ylab('Temporal variations')
  
  library(cowplot)
  #library(ggdraw)
  p212 = ggdraw()+
    draw_plot(p2)#+
    # draw_plot(p21,x = 0.65,y =0.25,
    #           width = 0.35,height = 0.35,
    #           scale = 1)
  
  p212
  # trend
  calc_trend_tws_mmk <- function(){
    source('R/data_management.R')
    source('R/shp_management.R')
    dryland = shp_management('dryland')
    dryland_cluster = shp_management('dryland_cluster')
    dryland_cluster = do.call(bind,dryland_cluster)
    dryland = crop(dryland,dryland_cluster)
    
    gpp = data_management('resampled_gpp')
    gpp = mask(crop(gpp,dryland),dryland)
    
    tws1 = data_management('grace_rl06_2312')
    tws1 = mask(crop(tws1,dryland),dryland)
    
    tws2 = data_management('smap_filled_tws_03_23')
    tws2 = mask(crop(tws2,dryland),dryland)
    
    twsdf = as.data.frame(tws1,xy = T)
    gppdf = as.data.frame(gpp,xy = T)
    
    naid1 = which(is.na(twsdf[,3]))
    naid2 = which(is.na(gppdf[,3]))
    if(length(naid1)!=0){
      twsdf = twsdf[-naid1,]
    }
    if(length(naid2)!=0){
      gppdf = gppdf[-naid2,]
    }
    loc1 = twsdf[,1:2]
    loc2 = gppdf[,1:2]
    
    twsdf = twsdf[,-c(1,2)]
    gppdf = gppdf[,-c(1,2)]
    
    gpp1 = apply(gppdf,1,sum)
    zeroid = which(gpp1 == 0)
    gppdf = gppdf[-zeroid,]
    loc2 = loc2[-zeroid,]
    
    loc11 = paste0(loc1[,1],'_',loc1[,2])
    loc21 = paste0(loc2[,1],'_',loc2[,2])
    idin = which(loc11 %in% loc21)
    loc1 = loc1[idin,]
    twsdf = twsdf[idin,]
    loc11 = loc11[idin]
    idin2 = which(loc21 %in% loc11)
    loc2 = loc2[idin2,]
    gppdf = gppdf[idin2,]
    
    calc_tws_mmk <- function(i){
      tmp = twsdf[i,]
      tmp = as.numeric(tmp)
      source('R/mmkTrend.R')
      source('R/stand_trend_fun.R')
      tmp = stand_trend_fun(tmp)
      tmp = mmkTrend(tmp)$Zc
      return(tmp)
    }
    
    calc_gpp_mmk <- function(i){
      tmp = gppdf[i,]
      tmp = as.numeric(tmp)
      source('R/mmkTrend.R')
      source('R/stand_trend_fun.R')
      tmp = stand_trend_fun(tmp)
      tmp = mmkTrend(tmp)$Zc
      return(tmp)
    }
    
    i = 1:nrow(twsdf)
    i <<- i
    twsdf <<- twsdf
    gppdf <<- gppdf
    
    library(doParallel)
    cl = makeCluster(25)
    clusterExport(cl,c('i','twsdf','gppdf'))
    system.time(ret_gpp <- parLapply(cl,i,calc_gpp_mmk))
    system.time(ret_tws <- parLapply(cl,i,calc_tws_mmk))
    stopCluster(cl)
    
    gpptrend = do.call(c,ret_gpp)
    twstrend = do.call(c,ret_tws)
    
    dftrend = data.frame(
      long = loc1[,1],
      lat = loc1[,2],
      MMK_TWS = twstrend,
      MMK_GPP = gpptrend
    )
    
    output = 'main_plot_output/Figure1_1120'
    dir.create(output)
    output = paste0(output,'/fig1_map_trend.csv')
    fwrite(dftrend,output)
    
  }
  calc_trend_tws_mmk_pvalue <- function(){
    source('R/data_management.R')
    source('R/shp_management.R')
    dryland = shp_management('dryland')
    dryland_cluster = shp_management('dryland_cluster')
    dryland_cluster = do.call(bind,dryland_cluster)
    dryland = crop(dryland,dryland_cluster)
    
    gpp = data_management('resampled_gpp')
    gpp = mask(crop(gpp,dryland),dryland)
    
    tws1 = data_management('grace_rl06_2312')
    tws1 = mask(crop(tws1,dryland),dryland)
    
    tws2 = data_management('smap_filled_tws_03_23')
    tws2 = mask(crop(tws2,dryland),dryland)
    
    
    
    twsdf = as.data.frame(tws1,xy = T)
    gppdf = as.data.frame(gpp,xy = T)
    
    naid1 = which(is.na(twsdf[,3]))
    naid2 = which(is.na(gppdf[,3]))
    if(length(naid1)!=0){
      twsdf = twsdf[-naid1,]
    }
    if(length(naid2)!=0){
      gppdf = gppdf[-naid2,]
    }
    loc1 = twsdf[,1:2]
    loc2 = gppdf[,1:2]
    
    twsdf = twsdf[,-c(1,2)]
    gppdf = gppdf[,-c(1,2)]
    
    gpp1 = apply(gppdf,1,sum)
    zeroid = which(gpp1 == 0)
    gppdf = gppdf[-zeroid,]
    loc2 = loc2[-zeroid,]
    
    loc11 = paste0(loc1[,1],'_',loc1[,2])
    loc21 = paste0(loc2[,1],'_',loc2[,2])
    idin = which(loc11 %in% loc21)
    loc1 = loc1[idin,]
    twsdf = twsdf[idin,]
    loc11 = loc11[idin]
    idin2 = which(loc21 %in% loc11)
    loc2 = loc2[idin2,]
    gppdf = gppdf[idin2,]
    
    calc_tws_mmk <- function(i){
      tmp = twsdf[i,]
      tmp = as.numeric(tmp)
      source('R/mmkTrend.R')
      source('R/stand_trend_fun.R')
      tmp = stand_trend_fun(tmp)
      tmp = mmkTrend(tmp)$p.value
      return(tmp)
    }
    
    calc_gpp_mmk <- function(i){
      tmp = gppdf[i,]
      tmp = as.numeric(tmp)
      source('R/mmkTrend.R')
      source('R/stand_trend_fun.R')
      tmp = stand_trend_fun(tmp)
      tmp = mmkTrend(tmp)$p.value
      return(tmp)
    }
    
    i = 1:nrow(twsdf)
    i <<- i
    twsdf <<- twsdf
    gppdf <<- gppdf
    
    library(doParallel)
    cl = makeCluster(25)
    clusterExport(cl,c('i','twsdf','gppdf'))
    system.time(ret_gpp <- parLapply(cl,i,calc_gpp_mmk))
    system.time(ret_tws <- parLapply(cl,i,calc_tws_mmk))
    stopCluster(cl)
    
    gpptrend = do.call(c,ret_gpp)
    twstrend = do.call(c,ret_tws)
    
    dftrend = data.frame(
      long = loc1[,1],
      lat = loc1[,2],
      MMK_TWS = twstrend,
      MMK_GPP = gpptrend
    )
    
    output = 'main_plot_output/Figure1_1120'
    dir.create(output)
    output = paste0(output,'/fig1_map_trend_pvalue.csv')
    fwrite(dftrend,output)
    
  }
  #calc_trend_tws_mmk()
  
  input1 = 'data_for_sharing/Figure1/fig1_map_trend.csv'
  dftrend = as.data.frame(fread(input1))
  
  input2 = 'data_for_sharing/Figure1/fig1_map_trend_pvalue.csv'
  dfp = as.data.frame(fread(input2))

  dfdist1 = data.frame(
    x = dfp[,3]
  )
  #a = rep(1:100,2)
  
  dftext2 = data.frame(
    x = 0.25,
    y = 40000000,
    ratio = round(length(which(dfdist1$x<0.05))/nrow(dfdist1)*100)
  )
  dftext2$label =paste0(
    "p<0.05: ",dftext2$ratio,'%'
  )
  
  pdist1 = ggplot()+
    geom_density( data = dfdist1,
                  aes(x = x,
                  ),fill = 'lightblue')+
    geom_text(data = dftext2,
              aes(x = x,y = y,
                  label = label),
              size = textsize,
              color = 'black',hjust = 0)+
    theme_void()+
    geom_hline(yintercept = 0)+
    geom_vline(xintercept = 0.05,
               linetype = 'dashed')+
    text_theme+
    theme(axis.ticks.length = unit(0.2,'cm'),
          axis.line = element_line(color = 'black',
                                   linewidth = 0.25),
          axis.ticks = element_line(color = 'black',
                                    linewidth = 0.25),
          axis.title.y = element_text(angle= 90))+
    #scale_y_continuous(breaks = c(0,*10^7,2*10^7,3),
    #                   limits = c(0,3.5))+
    scale_x_continuous(breaks = c(0,0.5,1))+
    xlab("")+
    ylab("Density")
  
  pdist1  
  

  dfdist2= data.frame(
    x = dfp[,4]
  )
  #a = rep(1:100,2)
  
  dftext3 = data.frame(
    x = 0.25,
    y = 100,
    ratio = round(length(which(dfdist2$x<0.05))/nrow(dfdist1)*100)
  )
  dftext3$label =paste0(
    "p<0.05: ",dftext3$ratio,'%'
  )
  
  pdist2 = ggplot()+
    geom_density( data = dfdist2,
                  aes(x = x,
                  ),fill = 'lightblue')+
    geom_text(data = dftext3,
              aes(x = x,y = y,
                  label = label),
              size = textsize,
              color = 'black',hjust = 0)+
    theme_void()+
    geom_hline(yintercept = 0)+
    geom_vline(xintercept = 0.05,
               linetype = 'dashed')+
    text_theme+
    theme(axis.ticks.length = unit(0.2,'cm'),
          axis.line = element_line(color = 'black',
                                   linewidth = 0.25),
          axis.ticks = element_line(color = 'black',
                                    linewidth = 0.25),
          axis.title.y = element_text(angle= 90))+
    #scale_y_continuous(breaks = c(0,*10^7,2*10^7,3),
    #                   limits = c(0,3.5))+
    scale_x_continuous(breaks = c(0,0.5,1))+
    xlab("")+
    ylab("Density")
  
  pdist2 

  
  
  naid = which(is.na(dftrend$MMK_TWS) | is.na(dftrend$MMK_GPP))
  dftrend = dftrend[-naid,]
  dftrend = dftrend[-which(abs(dftrend$MMK_TWS)>20 | abs(dftrend$MMK_GPP>20)),]
  dftrendm = reshape2::melt(dftrend,c('long','lat'))
  dftrendm$level = cut(dftrendm$value,
                       breaks = c(-20,seq(-5,5,1),20))
  source('R/data_management.R')
  source('R/shp_management.R')
  dryland = shp_management('dryland')
  dryland_cluster = shp_management('dryland_cluster')
  dryland_cluster = do.call(bind,dryland_cluster)
  dryland = crop(dryland,dryland_cluster)
  world = shp_management('world_new')
  world2 = crop(world,extent(-180,180,0,90))
  world = crop(world,dryland)
  
  library(RColorBrewer)
  fils = colorRampPalette(brewer.pal(9,'RdBu'))(length(unique(dftrendm$level)))
  nam1 = as(extent(shp_management('nam1')),"SpatialPolygons")
  nam2 = as(extent(shp_management('nam2')),"SpatialPolygons")
  eua1 = as(extent(shp_management('eua1')),"SpatialPolygons")
  eua2 = as(extent(shp_management('eua2')),"SpatialPolygons")
  eua3 = as(extent(shp_management('eua3')),"SpatialPolygons")
  
  
  drys = do.call(bind,list(nam1,nam2,eua1,eua2,eua3))
  
  exnam1 = round(extent(nam1))
  exnam2 = round(extent(nam2))
  exeua1 = round(extent(eua1))
  exeua2 = round(extent(eua2))
  exeua3 = round(extent(eua3))

  
  drysdf = fortify(drys)
  drysdf$variable = 'N'
  pmap = ggplot()+
    geom_polygon(data = world2,
                 aes(x = long,y = lat,group = group),
                 linewidth = 0.5,
                 color = 'black',
                 fill = 'transparent')+
    geom_polygon(data = dryland,
                 aes(x = long,y = lat,group = group),
                 linewidth = 0.5,
                 color = 'black',
                 fill = 'transparent')+
    geom_tile(data = dftrendm,
              aes(x = long,y = lat,fill = level))+
    # geom_polygon(data = drys,
    #              aes(x = long,y = lat,group = group),
    #              linewidth = 0.5,
    #              color = 'black',
    #              fill = 'transparent')+
    #scale_fill_distiller(palette = 'RdBu')+
    
    scale_fill_manual(values = fils)+
    #scale_fill_d
    #scale_fill_gradientn(colours = fils,
    #                     breaks = c(-20,seq(-5,5,1),20))+
    facet_wrap(~variable,nrow = 2)+
    # theme_bw()+
    # text_theme+
    # #coord_fixed(1.3)+

    # guides(fill = guide_legend(nrow = 2,
    #                            title = '(c-d) Spatial patterns of trends in TWS(c) and GPP(d)',
    #                            title.position = 'top'))+
    # theme(legend.position = 'bottom')+
    scale_x_continuous(breaks =c(-100,0,100),
                       labels = c('100°W',
                                  '0°',
                                  '100°E'))+
    
    scale_y_continuous(breaks = c(20,60),
                       labels = c(
                         paste0(c(20,60),
                                '°N')))+
    theme_void()+
    coord_fixed(1.3)+
    text_theme+
    theme(
      axis.ticks = element_line(linewidth =0.5,color = 'black'),
      axis.ticks.length = unit(0.25,'cm'),
      axis.title.x = element_text(margin = margin(t = 0.2,unit = 'cm')),
      axis.title.y = element_text(angle = 90)
    )+
    geom_hline(yintercept = c(20,60),
               linetype = 'dashed',
               color = 'black',
               linewidth = 0.5)+
    theme(strip.text = element_blank(),
          strip.background = element_blank())+
    guides(fill = guide_legend(title = ''))+
    theme(legend.position = 'bottom')+
    xlab('Longitude')+
    ylab('Latitude')
  
  legs_map = as_ggplot(get_legend(pmap))
  
  pmap = pmap + theme(legend.position = 'none')+
    coord_fixed(1.3)
  
  
  # count ratio 
  dfcount = dftrend
  
  ratio1 = length(which(dfcount$MMK_TWS<0 & dfcount$MMK_GPP >0))/nrow(dfcount)
  ratio2 = length(which(dfcount$MMK_TWS>0 & dfcount$MMK_GPP <0))/nrow(dfcount)
  ratio3 = length(which(dfcount$MMK_TWS<0 & dfcount$MMK_GPP <0))/nrow(dfcount)
  ratio4 = length(which(dfcount$MMK_TWS>0 & dfcount$MMK_GPP >0))/nrow(dfcount)
  
  ratio1 = ratio1 * 100
  ratio2 = ratio2 * 100 
  ratio3 = ratio3 * 100
  ratio4 = ratio4 * 100
  
  ratio1 = round(ratio1)
  ratio2 = round(ratio2)
  ratio3 = round(ratio3)
  ratio4 = round(ratio4)
  
  
  dfbar = data.frame(
    x = 4:1,
    y = c(ratio1,ratio2,ratio3,ratio4),
    cols = c('Decoupling','Decoupling','Coupling','Coupling')
  )
  
  fils = pal_lancet()(9)
  fils = c('Decoupling'=fils[7],
           'Coupling' = fils[1])
  dfbar$label = paste0(dfbar$y,'%')
  
  pbar = ggplot()+
    geom_bar(data = dfbar[c(1,3),],
             aes(x = x,y = y,fill = cols),
             color = 'transparent',
             width = 0.3,
             alpha = 1,
             position = position_dodge2(0.3),
             stat = 'identity')+
    geom_bar(data = dfbar[c(2,4),],
             aes(x = x,y = y,fill = cols),
             color = 'transparent',
             width = 0.3,
             alpha = 0.5,
             position = position_dodge2(0.3),
             stat = 'identity')+
    geom_text(data = dfbar,
              aes(x = x,y = y+8,label= label),
              size = textsize,
              color = 'black')+
    scale_fill_manual(values = fils)+
    ylim(0,60)+
    theme_bw()+
    text_theme+
    theme(panel.border = element_blank(),
          axis.line = element_line(color = 'black',
                                   linewidth = 0.25))+
    scale_x_continuous(breaks = c(1,2,3,4),
                       labels = c('D','C','B','A'))+
    
    guides(fill = guide_legend(title = '(e) Statistics of coupling relations between TWS and GPP',
                               title.position = 'top',
                               nrow = 1))+
    coord_flip()+
    xlab('')+
    ylab('Ratio (%)')
  
  pbar_leg = as_ggplot(get_legend(pbar))
  pbar = pbar+theme(legend.position = 'none')
  library(cowplot)
  pcom1 = plot_grid(pline,p212,nrow = 1,
                    rel_heights = c(1,1),
                    rel_widths = c(1,1))
  
  pcom2 = plot_grid(pmap,ggplot()+theme_void(),pbar,ggplot()+theme_void(),
                    nrow = 1,
                    rel_heights = c(1,1,1,1),
                    rel_widths = c(2,0.1,0.7,0.2))
  #pcoms = plot_grid(pcom1,pcom2,
  #                   ncol = 1,
  #                   rel_heights = c(1.3,2),
  #                   rel_widths = c(1,1))
  
  
  output = 'main_plot/Figure1/'
  dir.create(output)
  output1 = paste0(output,'/figure_line.pdf')
  output2 = paste0(output,'/figure_map.pdf')
  
  output3 = paste0(output,'/figure_line_leg.pdf')
  output4 = paste0(output,'/figure_point_leg.pdf')
  output5 = paste0(output,'/figure_map_leg.pdf')
  output6 = paste0(output,'/figure_bar_leg.pdf')
  
  ggsave(output1,pcom1,height = 8,
         width = 26,units = 'cm',dpi = 800)
  
  ggsave(output2,pmap,height = 14,
         width = 16,units = 'cm',dpi = 800)
  
  ggsave(output3,pline_leg,height = 20,
         width = 22,units = 'cm',dpi = 800)
  
  ggsave(output4,p2_leg,height = 20,
         width = 22,units = 'cm',dpi = 800)
  
  ggsave(output5,legs_map,height = 20,
         width = 22,units = 'cm',dpi = 800)
  
  ggsave(output6,pbar_leg,height = 20,
         width = 22,units = 'cm',dpi = 800)
  
  output7 = paste0(output,'/figure_pvalue_tws.pdf')
  output8 = paste0(output,'/figure_pvalue_gpp.pdf')
  # pdist1
  # pdist2
  ggsave(output7,pdist1,height = 6,
         width = 9,units = 'cm',dpi = 800)
  ggsave(output8,pdist2,height = 6,
         width = 9,units = 'cm',dpi = 800)
  output9 = paste0(output,'/figure_bar.pdf')
  ggsave(output9,pbar,height = 13,
         width = 7,units = 'cm',dpi = 800)


  
  
}
