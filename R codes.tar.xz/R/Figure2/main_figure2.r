main_figure2 <- function(

){
  plot_theme <-function(fontsize = 12){
    
    library(ggplot2)
    text_theme = theme(
      axis.text = element_text(size = fontsize,
                              color = 'black'),
      axis.text.y = element_text(angle = 90,
                                hjust = 0.5),
      axis.title =  element_text(size = fontsize,
                                color = 'black',
                                face = 'bold'),
      legend.text =  element_text(size = fontsize,
                                  color = 'black'),
      legend.title =  element_text(size = fontsize,
                                  color = 'black',
                                  face = 'bold'),
      strip.text =  element_text(size = fontsize,
                                color = 'black'),
      panel.grid = element_blank()
      #plot.background = elemen(),
      #panel.background = element_blank()
    )
    
    return(text_theme)
    
  }

  fig2_maptrends_tcw_sst <- function(){
  
    cluster_traj_to1 <- function(trajs,n = 10){
      get_longlat <- function(x){
        return(x)
      }
      
      long = aggregate(trajs$long,
                      list(trajs$routeid),
                      get_longlat)[,2]
      lat = aggregate(trajs$lat,
                      list(trajs$routeid),
                      get_longlat)[,2]
      
      longlat = cbind(long,lat)
      
      # n = 12
      if(nrow(longlat)<=n){
        ret = trajs
      }else{
        set.seed(4321)
        cls = kmeans(longlat,n)
        cls_type = as.numeric(cls$cluster)
        cls_center = cls$centers
        
        tmpheigth = aggregate(trajs$height,
                              list(trajs$routeid),
                              get_longlat)[,2]
        heights = 1
        for(i in 1:n){
          tmpid = which(cls_type == i)
          tmpheigth1 = tmpheigth[tmpid,]
          if(length(tmpid)==1){
            tmpheigth1 = as.numeric(tmpheigth1)
          }else{
            tmpheigth1 = apply(tmpheigth1,2,mean)
          }
          heights = c(heights,tmpheigth1)
        }
        heights = heights[-1]
        
        
        ret = data.frame(
          long = as.numeric(t(cls_center[,1:38])),
          lat = as.numeric(t(cls_center[,39:76])),
          height =heights,
          routeid = rep(1:n,each= 38)
        )
        
    }
    
    return(ret)
    }

    input = 'data_for_sharing/Figure2/trajs_from_nato_full_time'
    input = list.files(input,full.names = T)
    
    trajs = lapply(lapply(input,fread),as.data.frame)
    trajs = do.call(rbind,trajs)
    
    trajs1 = cluster_traj_to1(trajs,n = 30)
    
    
    input1 = 'data_for_sharing/Figure2/dftcw_trend.csv'
    input2 = 'data_for_sharing/Figure2/dft2m_sst_trend.csv'
    
    
    df1 = as.data.frame(fread(input1))
    df2 = as.data.frame(fread(input2))
    
    df1$level = cut(df1$value,
                    breaks = c(-19,
                              seq(-5,5,1),
                              445))
    df2$level = cut(df2$value,
                    breaks = c(-24,
                              seq(-5,5,1),
                              165))
    
    
    df1$type = 'TCW'
    df2$type = 'Temperature'
    
    cols1 = colorRampPalette(brewer.pal(9, "RdBu"))(
      length(unique(df1$level)))
    
    cols2 = rev(colorRampPalette(brewer.pal(9, "RdBu"))(
      length(unique(df2$level))))
    
    world = shp_management('world_new')
    world = crop(world,extent(-180,180,0,90))
    dryland = shp_management('dryland')
    
    library(ggnewscale)
    source("R/plot_theme.R")
    text_theme= plot_theme(12)
    
    dfpoints = data.frame(
      x = c(-90),
      y = 22
    )
    
    traj_col = c('#b10026','#fc4e2a','#feb24c')
    traj_col = colorRampPalette(traj_col)(10)
    #traj_col = rev(traj_col)
    traj_col = rep(traj_col,3)
    #traj1 = c('#f1b6da',,
    #          ,)
    #traj_col = traj_col[1]
    #traj_col = rep(traj_col,9)
    linetype = rep(c('solid',
                    'dashed',
                    'dotdash'),each = 10)
    
    traj_col = c('1'=traj_col[1],
                '2'=traj_col[2],
                '3'=traj_col[3],
                '4'=traj_col[4],
                '5'=traj_col[5],
                '6'=traj_col[6],
                '7'=traj_col[7],
                '8'=traj_col[8],
                '9'=traj_col[9],
                '10'=traj_col[10],
                '11'=traj_col[11],
                '12'=traj_col[12],
                '13'=traj_col[13],
                '14'=traj_col[14],
                '15'=traj_col[15],
                '16'=traj_col[16],
                '17'=traj_col[17],
                '18'=traj_col[18],
                '19'=traj_col[19],
                '20'=traj_col[20],
                '21'=traj_col[21],
                '22'=traj_col[22],
                '23'=traj_col[23],
                '24'=traj_col[24],
                '25'=traj_col[25],
                '26'=traj_col[26],
                '27'=traj_col[27],
                '28'=traj_col[28],
                '29'=traj_col[29],
                '30'=traj_col[30])
    
    linetype = c('1'=linetype[1],
                '2'=linetype[2],
                '3'=linetype[3],
                '4'=linetype[4],
                '5'=linetype[5],
                '6'=linetype[6],
                '7'=linetype[7],
                '8'=linetype[8],
                '9'=linetype[9],
                '10'=linetype[10],
                '11'=linetype[11],
                '12'=linetype[12],
                '13'=linetype[13],
                '14'=linetype[14],
                '15'=linetype[15],
                '16'=linetype[16],
                '17'=linetype[17],
                '18'=linetype[18],
                '19'=linetype[19],
                '20'=linetype[20],
                '21'=linetype[21],
                '22'=linetype[22],
                '23'=linetype[23],
                '24'=linetype[24],
                '25'=linetype[25],
                '26'=linetype[26],
                '27'=linetype[27],
                '28'=linetype[28],
                '29'=linetype[29],
                '30'=linetype[30])
    trajs1p = trajs1
    trajs1$type = 'TCW'
    trajs1p$type = 'Temperature'
    
    pmap = ggplot()+
      
      geom_tile(data = df1,
                aes(x = long,y = lat,
                    fill = level))+
      scale_fill_manual(values = cols1)+
      new_scale_fill()+
      geom_tile(data = df2,
                aes(x = long,y = lat,
                    fill = level))+
      scale_fill_manual(values = cols2)+
      
      geom_polygon(data= world,
                  aes(x = long,y = lat,
                      group= group),
                  linewidth = 0.3,
                  color = 'black',
                  fill = 'transparent')+
      geom_polygon(data= dryland,
                  aes(x = long,y = lat,
                      group= group),
                  linewidth = 0.3,
                  color = 'black',
                  fill = 'transparent')+
      geom_hline(yintercept = c(20,60),linetype = 'dashed',color = 'black')+
      facet_wrap(~type,nrow = 1)+
      #ggplot()+
      geom_path(data = trajs1,
                aes(x = long,y = lat,
                    group = factor(routeid),
                    color = factor(routeid),
                    linetype = factor(routeid)),
                #color = 'black',
                #color = 'blue',
                #alpha = 0.5,
                #color = brewer.pal(9,'Blues')[7],
                linewidth = 0.3)+
      geom_point(data = trajs1p,
                aes(x = long,y = lat,
                    group = factor(routeid)),
                #color = 'black',
                color = 'blue',
                alpha = 0.5,
                #color = brewer.pal(9,'Blues')[7],
                size = 0.05)+
      scale_color_manual(values = traj_col)+
      scale_linetype_manual(values = linetype)+
      theme_void()+
      text_theme+
      theme(strip.text = element_blank(),
            legend.position = 'none')+
      #theme(axis.title.y = element_text(angle = 90))+
      scale_y_continuous(breaks = c(20,60),
                        labels = c('20°N','60°N'))+
      scale_x_continuous(breaks = c(-100,0,100),
                        labels = c('100°W','0°','100°E'),
                        expand = c(0.02,0.02))+
      theme(axis.ticks.length = unit(0.25,'cm'),
            axis.ticks = element_line(linewidth = 0.5,
                                      color = 'black'),
            #axis.line.y =  element_line(linewidth = 0.5),
            plot.margin = unit(c(1,1,1,1), "cm"),)+
      coord_fixed(1.3)+
      #theme(legend.position = 'non')+
      xlab("")+
      ylab('')
      
    pmap
    output = 'main_plot/Figure2/maptrend.pdf'
    ggsave(output,pmap,height = 18,
          width = 21,
          units = 'cm',
          
          dpi = 800
    )
  }
  fig2_maptrends_tcw_sst()

  fig2_line <- function(){
    library(khroma) 
    library(data.table)
    stand_trend_fun <- function(x){
      if(is.na(mean(x))){
        x = rep(NA,240)
      }else{
        x = ts(x,start = c(2000,1),frequency = 12)
        x = decompose(x)$trend
        x = x[-which(is.na(x))]
        x = (x-mean(x))/sd(x)
      }
      
      return(x)
    }
    source("R/stand_trend_fun.R")
    
    tws = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/tws_dryland.csv'))
    t2m = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/t2m_dryland.csv'))
    gpp = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/gpp_dryland.csv'))


    source('R/import_index_heat_convection.R')
    # tcw data path: data_for_sharing/Figure2/TCW_NATO1.csv
    tcw = as.data.frame(fread('data_for_sharing/Figure2/TCW_NATO1.csv'))
    # sst data path: data_for_sharing/Figure2/SST_NATO1.csv
    sst = as.data.frame(fread("data_for_sharing/Figure2/SST_NATO1.csv"))
    
    df1 = data.frame(
      time = 1:240,
      TWS = tws[,1],
      T2M = t2m[,1],
      GPP = gpp[,1]
    ) 
    df2 = data.frame(
      time = 1:240,
      TWS = tws[,2],
      T2M = t2m[,2],
      GPP = gpp[,2]
    ) 
    
    df3 = data.frame(
      time = 1:240,
      SSTNATO1 = sst[,1],
      TCWNATO1 = tcw[,1]
    )
    
    df1m = reshape2::melt(df1,'time')
    df2m = reshape2::melt(df2,'time')
    df3m = reshape2::melt(df3,'time')
    df1m$type = 'e.'
    df2m$type = 'f.'
    df3m$type = 'd.'
    
    cols = khroma::color("vibrant")(7)
    
    cols = c('TWS' = cols[2],
            'T2M' = cols[5],
            'GPP' = cols[6],
            'SSTNATO1' = cols[5],
            'TCWNATO1' = cols[3])
    
    linetype = c('TWS' = 1,
                'T2M' = 1,
                'GPP' = 1,
                'SSTNATO1' = 2,
                'TCWNATO1' = 1)
    
    df = rbind(df1m,df2m,df3m)
    
    source("R/plot_theme.R")
    text_theme = plot_theme(11)
    dfm = df
    library(ggsci)
    #cols = pal_lancet()(9)[c(1,7)]
    dates = seq(as.Date('2003-07-01'),as.Date('2023-06-01'),'1 month')
    dates = substr(dates,1,4)
    # Basic line plot with two lines
    p = ggplot() +
      geom_line(data = dfm,aes(x = time,y= value,color = variable,
                              linetype = variable),
                linewidth = 1)+
      # scale_color_manual(values = cols)+
      scale_color_manual(values = cols)+
      scale_linetype_manual(values = linetype)+
      theme_bw()+
      #theme_void()+
      text_theme+
      theme(panel.border = element_blank(),
            axis.line = element_line(linewidth = 0.25,
                                    color = 'black'))+
      scale_x_continuous(breaks = c(1,120,240),
                        labels = dates[c(1,120,240)])+
      facet_wrap(~type,nrow = 1,scales = 'free')+
      theme(strip.background = element_blank(),
            strip.text = element_text(size = 12,
                                      color = 'black',
                                      hjust = 0,
                                      face = 'bold'))+
      guides(color = guide_legend(title = '',nrow = 1),
            linetype = guide_legend(title = '',nrow = 1))+
      theme(legend.position = 'bottom',
            legend.key.width = unit(1,'cm'))+
      #ggtitle(label = c('e.','f.','g.'))+
      labs(
        x = "Time (month)",
        y = "Standardized indices"
        #color = "Legend"
      ) 
    
    p
    #dir.create('main_plot/Figure2')

    ggsave('main_plot/Figure2/line.pdf',p,height = 6,
          width = 21.3,units = 'cm',dpi = 800)
    p = p+theme(legend.position = 'none')
    ggsave('main_plot/Figure2/line.pdf',p,height = 6,
          width = 21.3,units = 'cm',dpi = 800)
    
  }

  fig2_cor_calc <- function(
  ){
  
    calc_var_fun <- function(x){
      x = (x[240]-x[1])/6
      return(round(x*100))
    }
  
    library(khroma) 
    library(data.table)
    
    tws = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/tws_dryalnd.csv'))
    gpp = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/gpp_dryalnd.csv'))
    t2m = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/t2m_dryalnd.csv'))
    
    tcw = as.data.frame(fread('data_for_sharing/Figure2/TCW_NATO1.csv'))[,1]
    tcw = as.numeric(tcw)
    
    sst = as.data.frame(fread('data_for_sharing/Figure2/SST_NATO1.csv'))[,1]
    
    cor1 = max(ccf(tcw,sst)$acf) 
    
    tcw_a = import_index_coupling_decouping_byname_mapratio('tcw','dryland')
    colnames(tcw_a) = c('GnDry','BnDry')
    fwrite(tcw_a,'data_for_sharing/Figure2/Index_by_system/tcw_dryland.csv')
    
    cor21 = max(ccf(tcw_a[,1],tcw)$acf)
    cor22 = max(ccf(tcw_a[,2],tcw)$acf)

    #pr_a = import_index_coupling_decouping_byname('pr','dryland')
    pre_ac = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/pe_dryalnd.csv'))
    vpd_ac = as.data.frame(fread('data_for_sharing/Figure2/Index_by_system/vpd_dryalnd.csv'))
    
    cor3a = min(ccf(pre_ac[,1],vpd_ac[,1])$acf) 
    cor3c = min(ccf(pre_ac[,2],vpd_ac[,2])$acf) 
    
    var_vpda = calc_var_fun(vpd_ac[,1]) 
    var_vpdc = calc_var_fun(vpd_ac[,2]) 
    var_prea = calc_var_fun(pre_ac[,1]) 
    var_prec = calc_var_fun(pre_ac[,2]) 
    var_tcwa = calc_var_fun(tcw_a[,1])
    var_tcwc = calc_var_fun(tcw_a[,2])
    
    cor_sst_t2ma = max(ccf(t2m[,1],sst)$acf)
    cor_sst_t2mc = max(ccf(t2m[,2],sst)$acf)
    
    cor_sst_t2ma = max(ccf(t2m[,1],sst)$acf)
    cor_sst_t2mc = max(ccf(t2m[,2],sst)$acf)
    
    var_t2ma = calc_var_fun(t2m[,1])
    var_t2mc = calc_var_fun(t2m[,2])
    var_sst1 = calc_var_fun(sst)
    var_tcw = calc_var_fun(tcw) 
    var_t2ma
    var_t2mc
    
    cor_pre_twsa = max(ccf(tws[,1],pre_ac[,1])$acf)
    cor_pre_twsc = max(ccf(tws[,2],pre_ac[,2])$acf)
    var_twsa = calc_var_fun(tws[,1])
    var_twsc = calc_var_fun(tws[,2])
    
    prato13 = as.data.frame(fread('data_for_sharing/Figure2/PrNATO_1_3.csv'))
    var_prato1 = calc_var_fun(prato13[,1])
    var_prato3 = calc_var_fun(prato13[,2])

    cor_gppa_sst = max(ccf(sst,gpp[,1])$acf)
    cor_gppa_t2ma = max(ccf(t2m[,1],gpp[,1])$acf)
    
    calc_var_fun(pre_ac[,1])
    calc_var_fun(pre_ac[,2])

  }


}