main_figure4 <- function(
){
  library(ggplot2)
  library(data.table)
 
  fig4_line_gppac_25_99_ensemble_mapratio <- function(
    fontsize=12,
    textsize = 4
  ){
    library(paletteer)
    # apply prepare_data_fig4_line_ensemble
  
    date = seq(as.Date('2003-07-01'),as.Date('2099-06-01'),'1 month')
    s1 =which(date == '2024-01-01')
    s2 = which(date == '2099-06-01')
    date = date[s1:s2]
    
    library(ggsci)
    output = 'data_for_sharing/Figure4/linea_gpp'
    output1 = paste0(output,'/','gpp_mean_systema245.csv')
    output2 = paste0(output,'/','gpp_mean_systema585.csv')
    output3 = paste0(output,'/','gpp_mean_systemc245.csv')
    output4 = paste0(output,'/','gpp_mean_systemc585.csv')
    output5 = paste0(output,'/','gpp_mean_systemac245.csv')
    output6 = paste0(output,'/','gpp_mean_systemac585.csv')
    
    gpp_mean_systema245 = as.data.frame(fread(output1))
    gpp_mean_systema585 = as.data.frame(fread(output2))
    gpp_mean_systemc245 = as.data.frame(fread(output3))
    gpp_mean_systemc585 = as.data.frame(fread(output4))
    gpp_mean_systemac245 = as.data.frame(fread(output5))
    gpp_mean_systemac585 = as.data.frame(fread(output6))
    
    source("R/plot_theme.R")
    text_theme = plot_theme(fontsize)
    ids = 1:21
    df_ensemble = data.frame(
      time = 1:906,
      gppa_245 = gpp_mean_systema245$ensemble,
      gppa_585 = gpp_mean_systema585$ensemble,
      gppc_245 = gpp_mean_systemc245$ensemble,
      gppc_585 = gpp_mean_systemc585$ensemble
    )
    
    df_ribbiona_245 = data.frame(
      time = 1:906,
      min = apply(gpp_mean_systema245[,ids],1,min),
      max = apply(gpp_mean_systema245[,ids],1,max)
    )
    df_ribbiona_585 = data.frame(
      time = 1:906,
      min = apply(gpp_mean_systema585[,ids],1,min),
      max = apply(gpp_mean_systema585[,ids],1,max)
    )
    
    df_ribbionc_245 = data.frame(
      time = 1:906,
      min = apply(gpp_mean_systemc245[,ids],1,min),
      max = apply(gpp_mean_systemc245[,ids],1,max)
    )
    df_ribbionc_585 = data.frame(
      time = 1:906,
      min = apply(gpp_mean_systemc585[,ids],1,min),
      max = apply(gpp_mean_systemc585[,ids],1,max)
    )
    
    df_ensemble = reshape2::melt(df_ensemble,c('time'))
    
    cols = pal_lancet()(9)[c(1,7)]
    cols = c(cols,cols)
    linetypes =c(1,1,4,4)
    
    year_label = substr(date,1,4)
    pline = ggplot()+
      geom_vline(xintercept = 260)+
      geom_ribbon(data = df_ribbiona_245,
                  aes(x = time,ymin = min,ymax = max),
                  alpha = 0.2,
                  fill = cols[1])+
      geom_ribbon(data = df_ribbiona_585,
                  aes(x = time,ymin = min,ymax = max),
                  alpha = 0.2,
                  fill = cols[2])+
      geom_ribbon(data = df_ribbionc_245,
                  aes(x = time,ymin = min,ymax = max),
                  alpha = 0.2,
                  fill = cols[1])+
      geom_ribbon(data = df_ribbionc_585,
                  aes(x = time,ymin = min,ymax = max),
                  alpha = 0.2,
                  fill = cols[2])+
      geom_line(data = df_ensemble,
                aes(x = time,y = value,color= variable,
                    linetype = variable),
                linewidth = 0.5)+
      #scale_color_manual(values = cols)+
      scale_color_lancet()+
      scale_linetype_manual(values = linetypes)+
      scale_x_continuous(breaks = c(1,453,906),
                        labels = year_label[c(1,453,906)])+
      theme_bw()+
      text_theme+
      xlab('Time (month)')+
      ylab("GPP")
    
    pline
    
    source("R/plot_theme.R")
    text_theme = plot_theme(fontsize)
    ids = 1:21
    df_ensemble2o = data.frame(
      time = 1:906,
      GPP_SSP245 = gpp_mean_systemac245$ensemble,
      GPP_SSP585 = gpp_mean_systemac585$ensemble
    )
    
    df_ribbionac_245 = data.frame(
      time = 1:906,
      min = apply(gpp_mean_systemac245[,ids],1,min),
      max = apply(gpp_mean_systemac245[,ids],1,max)
    )
    df_ribbionac_585 = data.frame(
      time = 1:906,
      min = apply(gpp_mean_systemac585[,ids],1,min),
      max = apply(gpp_mean_systemac585[,ids],1,max)
    )
    
    
    #E8F5E9FF, #C8E6C9FF, #A5D6A7FF, #81C784FF, #66BB6AFF, #4CAF50FF, #43A047FF, #388E3CFF, #2E7D32FF, #1B5E20FF
    
    cols = paletteer_d("MoMAColors::Alkalay2")[c(5,7)]
    
    #cols = pal_lancet()(9)[c(1,7)]
    #cols = c(cols,cols)
    
    linetypes =c(1,1,4,4)
    
    year_label = substr(date,1,4)
    #a = apply(gpp_mean_systema585[,1:20],1,mean)
    x = 1:length(as.numeric(gpp_mean_systemac585$ensemble))
    y = as.numeric(gpp_mean_systemac585$ensemble)
    # Fit initial linear model
    lm_model <- lm(y ~ x)
    
    # Install and load the segmented package
    #install.packages("segmented")
    library(segmented)
    # Fit segmented (piecewise) regression model with guessed change point at x = 100
    system.time(seg_model <- segmented(lm_model, seg.Z = ~x))
    
    changepoint <- seg_model$psi[1, "Est."]
    changepoint = round(changepoint)
    print(changepoint)
    
    
    output = 'data_for_sharing/Figure4/linea_tws'
    dir.create(output)
    output1_tws = paste0(output,'/tws_245.csv')
    output2_tws = paste0(output,'/tws_585.csv')
    
    tws_245 = as.data.frame(fread(output1_tws))
    tws_585 = as.data.frame(fread(output2_tws))
    
    tws_245_mean = apply(tws_245[,1:20],1,mean)
    tws_585_mean = apply(tws_585[,1:20],1,mean)
    
    date1 = seq(as.Date('2003-07-01'),as.Date('2099-06-01'),'1 month')
    s1 =which(date1 == '2024-01-01')
    
    tws_245_mean = tws_245_mean[s1:1152]
    tws_585_mean = tws_585_mean[s1:1152]
    
    dftwso = data.frame(
      x = 1:length(tws_245_mean),
      TWS_SSP245 = tws_245[s1:1152,21],#tws_245_mean,
      TWS_SSP585 = tws_585[s1:1152,21]#tws_585_mean
    )
    
    df_ensemble2 = reshape2::melt(df_ensemble2o,c('time'))
    dftws = reshape2::melt(dftwso,'x')
    
    fils = paletteer::paletteer_d('beyonce::X87')
    fils = c('TWS_SSP245'= fils[5],
            'TWS_SSP585' = fils[2])
    
    fils = colorspace::adjust_transparency(fils,0.5)
    
    dfy1 = data.frame(
      x = 0,
      y = 0,
      yend = Inf
    )
    dfy2 = data.frame(
      x = Inf,
      y = 0,
      yend = -25/30
    )
    cols = c('GPP_SSP245'='#006400',
            'GPP_SSP585'='#CD9B1D',
            "TWS_SSP245"= fils[1],
            'TWS_SSP585'= fils[2])#,
            #'#f9e266','#eaf966'
    
    dfppoint1 = data.frame(
      x = 1000,
      y = c(
            gpp_mean_systemac585$ensemble[c(changepoint,906)]),
      variable = rep(c('GPP_SSP585'),
                    each = 2)
    )
    
    dfppoint2 = data.frame(
      x = c(changepoint,906),
      y =c(
        gpp_mean_systemac245$ensemble[c(changepoint,906)]),
      variable = rep(c('GPP_SSP245'),
                    each = 2)
    )
    
    dfsegp1 = data.frame(
      x = 1000,
      y = gpp_mean_systemac585$ensemble[c(changepoint)],
      yend = gpp_mean_systemac585$ensemble[c(906)]
    )
    
    source("R/stand_fun.R")
    
    gpp1line = stand_fun(gpp_mean_systemac245$ensemble)
    gpp2line = stand_fun(gpp_mean_systemac585$ensemble)
    
    dfvargpplabel = data.frame(
      x = 1000+30,
      y = mean(gpp_mean_systemac585$ensemble[c(changepoint,906)]),
      var = (gpp2line[906]-
              gpp2line[changepoint])/6
        
    )
    dfvargpplabel$label = paste0(
      round(gpp_mean_systemac585$ensemble[906]-
              gpp_mean_systemac585$ensemble[changepoint],1),'(',
      round(dfvargpplabel$var*100,1),
                                '%)')
    
    dfvargpplabel2 = data.frame(
      x = mean(c(906,changepoint)),
      y = mean(gpp_mean_systemac245$ensemble[c(changepoint,906)])-0.75,
      var = (gpp1line[906]-
              gpp1line[changepoint])/6
      
    )
    dfvargpplabel2$label = paste0(
      round(gpp_mean_systemac245$ensemble[906]-
              gpp_mean_systemac245$ensemble[changepoint],2),'(',
      round(dfvargpplabel2$var*100,1),
                                '%)')
    
    dfsegp2 = data.frame(
      x = 1000-15,
      xend = 1000+15,
      y = gpp_mean_systemac585$ensemble[c(changepoint,906)]
    )
    
    dfsegp3 = data.frame(
      x = c(changepoint),
      xend = 906,
      y = gpp_mean_systemac245$ensemble[c(changepoint)],
      yend = gpp_mean_systemac245$ensemble[c(906)]
    )
    
    dfh1 = data.frame(
      x = c(changepoint,906),
      xend = 1000,
      y = gpp_mean_systemac585$ensemble[c(changepoint,906)]-1
    )
    dfh2 = data.frame(
      x = c(changepoint,906),
      xend = 1000,
      y = dftwso$TWS_SSP585[c(changepoint,906)]/30
    )
    
    dfppoint3 = data.frame(
      x = 1000,
      y = c(
        dftwso$TWS_SSP585[c(changepoint,906)]),
      variable = rep(c('TWS_SSP585'),
                    each = 2)
    )
    
    dfppoint31 = data.frame(
      x = 1,
      y = c(
        dftwso$TWS_SSP585[c(1,906)]),
      variable = rep(c('TWS_SSP585'),
                    each = 2)
    )
    
    dfppoint4 = data.frame(
      x = c(changepoint,906),
      y =c(
        dftwso$TWS_SSP245[c(changepoint,906)]),
      variable = rep(c('TWS_SSP245'),
                    each = 2)
    )
    
    dfsegp5 = data.frame(
      x = 1000,
      y = dftwso$TWS_SSP585[c(changepoint)],
      yend =  dftwso$TWS_SSP585[c(906)]
    )
    
    dfsegp51 = data.frame(
      x = 1,
      y = dftwso$TWS_SSP585[c(1)],
      yend =  dftwso$TWS_SSP585[c(906)]
    )
    
    mdftwso2 = stand_fun(dftwso$TWS_SSP585)
    mdftwso1 = stand_fun(dftwso$TWS_SSP245)
    
    dfvartwslabel = data.frame(
      x = 1000+30,
      y = mean( dftwso$TWS_SSP585[c(changepoint,906)]),
      var = ( mdftwso2[906]-
                mdftwso2[changepoint])/ 6
      
    )
    dfvartwslabel$label = paste0(
      round(dftwso$TWS_SSP585[906]-dftwso$TWS_SSP585[changepoint],1),'(',
      round(dfvartwslabel$var*100,1),
                                '%)')
    
    dfvartwslabel2 = data.frame(
      x = mean(c(906,changepoint)),
      y = mean( dftwso$TWS_SSP245[c(changepoint,906)]),
      var = (dftwso$TWS_SSP245[906]-
              dftwso$TWS_SSP245[changepoint])/dftwso$TWS_SSP245[changepoint]
      
    )
    dfvartwslabel2$label = paste0(
      round(dftwso$TWS_SSP245[906]-dftwso$TWS_SSP245[changepoint],1),'(',
      round(dfvartwslabel2$var*100,1),
                                  '%)')
    
    dfvartwslabel3 = data.frame(
      x = -20,
      y = mean(dftwso$TWS_SSP585[c(1,906)]),
      var = (mdftwso2[906]-
              mdftwso2[1])/6
      
    )
    dfvartwslabel3$label = paste0(
      round(dftwso$TWS_SSP585[906]-dftwso$TWS_SSP585[1],1),'(',
      round(dfvartwslabel3$var*100,1),
      '%)')
    
    
    dfsegp6 = data.frame(
      x = 1000-15,
      xend = 1000+15,
      y = dftwso$TWS_SSP585[c(changepoint,906)]
    )
    
    
    dfsegp61 = data.frame(
      x = 1-15,
      xend = 1+15,
      y = dftwso$TWS_SSP585[c(1,906)]
    )
    
    dfsegp7 = data.frame(
      x = c(changepoint),
      xend = 906,
      y = dftwso$TWS_SSP245[c(changepoint)],
      yend = dftwso$TWS_SSP245[c(906)]
    )
    
    
    pline2 = ggplot()+
      geom_vline(xintercept = c(changepoint,906),linewidth = 0.5,color = 'black',
                linetype = 'dashed')+
      # geom_segment(data = dfy1,
      #              aes(x = x,xend = x,y = y,yend = yend),
      #              linewidth = 0.5,
      #              arrow = arrow(20,unit(0.25,'cm'),type = 'closed'))+
      geom_segment(data = dfy2,
                  aes(x = x,xend = x,y = y,yend = yend),
                  linewidth = 0.8
                  # arrow = arrow(20,unit(0.25,'cm'),type = 'closed')
                  )+
      geom_hline(yintercept = 0,linewidth = 0.5,color = 'black')+

      geom_line(data = df_ensemble2,
                aes(x = time,y = value-1,color= variable),
                linewidth = 1)+
      geom_segment(data = dfsegp1,
                  aes(x = x,xend = x,y = y-1,yend = yend-1),
                  linewidth = 0.5,
                  color = 'black',
                  arrow = arrow(20,unit(0.25,'cm'),type = 'open')
      )+
      geom_segment(data = dfsegp5,
                  aes(x = x,xend = x,y = y/30,yend = yend/30),
                  linewidth = 0.5,
                  color = 'black',
                  arrow = arrow(20,unit(0.25,'cm'),type = 'open')
      )+
      geom_segment(data = dfsegp51,
                  aes(x = x,xend = x,y = y/30,yend = yend/30),
                  linewidth = 0.5,
                  color = 'black',
                  arrow = arrow(20,unit(0.25,'cm'),type = 'open')
      )+
      geom_text(data = dfvargpplabel,
                aes(x=x,y = y-1,label = label),
                size = textsize,
                angle = 90,
                color = 'black')+
      geom_text(data = dfvargpplabel2,
                aes(x=x,y = y,label = label),
                size = textsize,
                color = 'black')+
      geom_text(data = dfvartwslabel,
                aes(x=x,y = y/30,label = label),
                size = textsize,
                angle = 90,
                color = 'black')+
      geom_text(data = dfvartwslabel3,
                aes(x=x,y = y/30,label = label),
                size = textsize,
                angle = 90,
                color = 'black')+
    
      geom_segment(data = dfsegp2,
                  aes(x = x,xend = xend,y = y-1,yend = y-1),
                  linewidth = 0.5
      )+
      geom_segment(data = dfsegp3,
                  aes(x = x,xend = xend,y = y-0.8,yend = yend-0.8),
                  linewidth = 0.5,
                  color = 'black',
                  arrow = arrow(20,unit(0.25,'cm'),type = 'open')
      )+
      geom_segment(data = dfsegp6,
                  aes(x = x,xend = xend,y = y/30,yend = y/30),
                  linewidth = 0.5
      )+
      geom_segment(data = dfsegp61,
                  aes(x = x,xend = xend,y = y/30,yend = y/30),
                  linewidth = 0.5
      )+
      geom_point(data = dfppoint1,
                aes(x = x,y = y-1,color = variable ),
                size = 1.5,
                shape = 16)+
      geom_point(data = dfppoint1,
                aes(x = x,y = y-1,color = variable ),
                size = 4,
                shape = 1)+
      geom_point(data = dfppoint2,
                aes(x = x,y = y-0.8,color = variable ),
                size = 1.5,
                shape = 16)+
      geom_point(data = dfppoint2,
                aes(x = x,y = y-0.8,color = variable ),
                size = 4,
                shape = 1)+
      
      geom_point(data = dfppoint3,
                aes(x = x,y = y/30,color = variable ),
                size = 1.5,
                shape = 16)+
      geom_point(data = dfppoint3,
                aes(x = x,y = y/30,color = variable ),
                size = 4,
                shape = 1)+
      geom_point(data = dfppoint31,
                aes(x = x,y = y/30,color = variable ),
                size = 1.5,
                shape = 16)+
      geom_point(data = dfppoint31,
                aes(x = x,y = y/30,color = variable ),
                size = 4,
                shape = 1)+
      geom_ribbon(data = df_ribbionac_245,
                  aes(x = time,ymin = min-1,ymax = max-1),
                  alpha = 0.18,
                  fill = cols[1])+
      geom_ribbon(data = df_ribbionac_585,
                  aes(x = time,ymin = min-1,ymax = max-1),
                  alpha = 0.18,
                  fill = cols[2])+
      
      geom_area(data = dftws[which(dftws$variable == 'TWS_SSP585'),],
                aes(x = x,y = value/30,fill = variable),
                #fill = 'transparent',
                #color = fils[2],
                alpha = 0.5
                )+
      geom_area(data = dftws[which(dftws$variable == 'TWS_SSP245'),],
                aes(x = x,y = value/30,fill = variable),
                alpha = 0.5)+
      # geom_text(data = dfvartwslabel2,
      #           aes(x=x,y = y/35,label = label),
      #           size = textsize,
      #           color = 'white')+
      # geom_segment(data = dfsegp7,
      #              aes(x = x,xend = xend,y = y/30,yend = yend/30),
      #              linewidth = 0.5,
      #              color = 'black',
      #              arrow = arrow(20,unit(0.25,'cm'),type = 'open')
      # )+
      geom_segment(data = dfh1,
                  aes(x = x,xend = xend,y = y,yend = y),
                  linewidth = 0.5,
                  linetype = 'dashed',
                  color = 'black'
      )+
      geom_segment(data = dfh2,
                  aes(x = x,xend = xend,y = y,yend = y),
                  linewidth = 0.5,
                  linetype = 'dashed',
                  color = 'black'
      )+
      scale_color_manual(values = cols)+
      #scale_color_lancet()+
      scale_linetype_manual(values = linetypes)+
      scale_fill_manual(values = fils)+
      scale_x_continuous(breaks = c(1,changepoint,906),
                        labels = year_label[c(1,changepoint,906)])+
      scale_y_continuous(
        name = "GPP",
        breaks = c(0,0.5,1),
        labels = c(0,0.5,1)+1,
        sec.axis = sec_axis(~ ., name = "TWS",breaks = c(0,-0.2,-0.4),
                            labels = c(0,-0.2,-0.4)*30)  # Secondary axis
      ) +
      #theme_bw()+
      theme_void()+
      text_theme+
      theme(axis.text.y.right = element_text(hjust = 0.5),
            axis.line.x = element_line(linewidth = 0.5,
                                      color = 'black',
                                      arrow = arrow(20,unit(0.25,'cm'),
                                                    type = 'closed')),
            axis.line.y.left = element_line(linewidth = 0.5,
                                            color = 'black',
                                            arrow = arrow(20,unit(0.25,'cm'),
                                                          type = 'closed')),
            axis.ticks = element_line(linewidth =0.5,color = 'black'),
            axis.ticks.length = unit(0.25,'cm'),
            axis.title.x = element_text(margin = ggplot2::margin(t = 0.2,unit = 'cm')),
            axis.title.y = element_text(angle = 90),
            panel.background = element_blank(),
            plot.background = element_blank()
      )+
      theme(legend.position = 'top')+
      guides(color = guide_legend(title = ''),
            fill = guide_legend(title =''))+
      xlab('Time (month)')+
      ylab("GPP")
    pline2
    
    pline3 =pline2+theme(legend.position = 'none')
    return(list(pline3))
  }
  # Note
  #System A: System Green-Dry
  #System C: System Brown-Dry
  #A2C1: System Green-Dry to Brown-Dry under SSP245
  #A2C2: System Green-Dry to Brown-Dry under SSP585
  #A2Cb: System Green-Dry to Brown-Dry both SSP245 and SSP585
  #A2CN: System Green-Dry by 2099

  # temporal variations in 
  library(paletteer)
  plines = fig4_line_gppac_25_99_ensemble_mapratio(fontsize = 12,
                                          textsize = 3.3)
  pline = plines[[1]]

  # output1 = 'main_plot/Figure4/fig_linea.pdf'
  # ggsave(output1,pline,height = 5,width = 22,
  #        units = 'cm',dpi = 800)
  
  fig_tip_year_ssp245_585_ensemble_2d <- function(
  ){
    
    library(ggplot2)
    # 1. import data
    ##############
    input = 'data_for_sharing/Figure3/aligned_spatial_df_indices'
    input1 = paste0(input,'/twsdf.csv')
    input2 = paste0(input,'/gppdf.csv')
    input3 = paste0(input,'/rootsmdf.csv')
    input4 = paste0(input,'/evadf')
    input5 = paste0(input,'/t2mdf.csv')
    input6 = paste0(input,'/prdf.csv')
    input7 = paste0(input,'/loc.csv')
    input8 = paste0(input,'/vpdinc.csv')
    input9 = paste0(input,'/vpddec.csv')
    
    twsdf = as.data.frame(fread(input1))
    gppdf = as.data.frame(fread(input2))
    rootsmdf = as.data.frame(fread(input3))
    evadf = as.data.frame(fread(input4))
    t2mdf = as.data.frame(fread(input5))
    prdf = as.data.frame(fread(input6))
    loc = as.data.frame(fread(input7))
    longlat1 = paste0(loc[,1],'_',loc[,2])
    
    vpd1 = as.data.frame(fread(input8))
    vpd2 = as.data.frame(fread(input9))
    
    #source('R/stand_trend2.R')
    input_increase_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/increase_gpp_cwsi.csv'
    input_decrease_gpp_cwsi = 'data_for_sharing/Figure3/coup_decoup_cwsi/decrase_gpp_cwsi.csv'
    
    inc_gpp = as.data.frame(fread(input_increase_gpp_cwsi))
    dec_gpp = as.data.frame(fread(input_decrease_gpp_cwsi))
    
    inc_gpp$long_lat = paste0(inc_gpp[,1]+ 0.125,'_',inc_gpp[,2]+ 0.125)
    dec_gpp$long_lat = paste0(dec_gpp[,1]+ 0.125,'_',dec_gpp[,2]+ 0.125)
    
    inc_gpp = inc_gpp[which(inc_gpp$CWSI<0),]
    dec_gpp = dec_gpp[which(dec_gpp$CWSI<0),]
    
    id1 = which(longlat1 %in% inc_gpp$long_lat)
    id2 = which(longlat1 %in% dec_gpp$long_lat)
    
    
    t2m1  = t2mdf[id1,]
    t2m2  = t2mdf[id2,]
    
    smdf1 = rootsmdf[id1,]
    smdf2 = rootsmdf[id2,]
    
    twsdf1 = twsdf[id1,]
    twsdf2 = twsdf[id2,]
    
    gpp1 = gppdf[id1,]
    gpp2 = gppdf[id2,]
    
    loc1 = loc[id1,]
    loc2 = loc[id2,]
    ##############
    
    # models= read.csv('data_for_sharing/Figure4/cmip6_models.csv')[,2]
    
    input_ids1 = 'data_for_sharing/Figure4/tip_ids/ssp245'
    input_ids2 = 'data_for_sharing/Figure4/tip_ids/ssp585'
    
    input_ids1 = paste0(input_ids1,'/tips_',models,'.csv')
    input_ids2 = paste0(input_ids2,'/tips_',models,'.csv')
    
    tipid_245 = do.call(cbind,lapply(lapply(input_ids1,fread),as.data.frame))
    tipid_585 = do.call(cbind,lapply(lapply(input_ids2,fread),as.data.frame))
    
    colnames(tipid_585) = models
    colnames(tipid_245) = models
    
    # mean_fun <- function(x){
    #   sumx = sum(x,na.rm = T)
    #   if(sumx == 0){
    #     x = 0
    #   }else{
    #     zeroid = which(x == 0)
    #     if(length(zeroid) != 0){
    #       x = x[-zeroid]
    #       x = mean(x,na.rm = T)
    #     }else{
    #       x = mean(x,na.rm = T)
    #     }
    #   }
    #   return(x)
    # }
    
    # tipid_ensem245 = tipid_245[,21]
    # tipid_ensem585 = tipid_585[,21]

    
    # group_id_by_years <- function(x){
    #   dates = seq(as.Date('2003-07-01'),
    #               as.Date('2099-06-01'),
    #               '1 month')
    #   if(x == 0 | is.na(x)){
    #     tmpdate = 0
    #   }else{
    #     tmpdate = substr(dates[round(x)],1,4)
    #     tmpdate = as.numeric(tmpdate)
    #   }
    #   return(tmpdate)
    # }
    # tipid_ensem245 = sapply(tipid_ensem245,group_id_by_years)
    # tipid_ensem585 = sapply(tipid_ensem585,group_id_by_years)

    output1 = 'data_for_sharing/Figure4/tipid_ensem245.csv'
    output2 = 'data_for_sharing/Figure4/tipid_ensem585.csv'
    
    #fwrite(data.frame(x = tipid_ensem245),output1)
    #fwrite(data.frame(x = tipid_ensem585),output2)
    
    tipid_ensem245 = as.data.frame(fread(output1))[,1]
    tipid_ensem585 = as.data.frame(fread(output2))[,1]
    
    #tipid_test = sapply(as.numeric(tipid_245[,21]),group_id_by_years)
    dftips1 = data.frame(
      long = loc1[,1],
      lat = loc1[,2],
      Tip_year245 = tipid_ensem245#tipid_ensem245
    )
    
    dftips2 = data.frame(
      long = loc1[,1],
      lat = loc1[,2],
      Tip_year245 = tipid_ensem585
    )
    
    fig_sub_tranfer2d <- function(df){
      cols_id <- c("#855336", "grey","#CC5500", "#4682B4", "#DAA520")
      
      show_col(cols_id)
      
      cols_id = c('2' = cols_id[1], # A2Cb
                  '3' = cols_id[3], # A2C2
                  '4' = cols_id[5], # A2C1
                  '5' = cols_id[4], # A2CN
                  '1' = cols_id[2] # C
      )
      
      dfm = reshape2::melt(df,c('long','lat'))
      
      dfm$level = cut(dfm$value,
                        breaks = c(0,1,2100),
                        right = FALSE)
      
      dfm1 = dfm[which(dfm$level == '[0,1)'),]
      dfm2 = dfm[which(dfm$level == '[1,2.1e+03)'),]
    
      
      dfm1$type = 'A2CN'
      dfm2$type = 'A2C1'
      #dfm3$type = '2003~2063'
      #dfm4$type = '2003~2099'
      df5 = data.frame(
        long = loc2[,1],
        lat = loc2[,2]
      )
      
      dfms = rbind(dfm1,dfm2)
      
      
      source('R/shp_management.R')
      dryland = shp_management('dryland')
      dryland2 = shp_management('dryland_cluster')
      dryland2 = do.call(bind,dryland2)
      dryland = crop(dryland,dryland2)
      world = shp_management('world_new')
      world = crop(world,dryland)
      source("R/plot_theme.R")
      text_theme = plot_theme(12)
      
      cols = ggsci::pal_futurama()(4)[1:4]
      
      source("R/plot_theme.R")
      text_theme = plot_theme(12)
      cols = c('2003~2033'=cols[3],
              '2003~2063'=cols[1],
              '2003~2099'=cols[2],
              'No Transfer' = cols[4])
      
      facet_labels <- data.frame(
        type = c('2003~2033','2003~2063','2003~2099'),
        label = c("a", "b", "c"),
        x = -Inf, y = Inf # Position labels in the top-left corner of each facet
      )
      
      
      p = ggplot()+
        geom_polygon(data = dryland,
                    aes(x = long,y = lat,group = group),
                    linewidth = 0.25,
                    fill = 'transparent',
                    color = 'black')+
        # geom_polygon(data = dryland,
        #              aes(x = long,y = lat,group = group),
        #              linewidth = 0.5,
        #              fill = 'grey',)+
        geom_tile(data = df5,
                  aes(x = long,y = lat),
                  fill = 'grey')+
        geom_tile(data = dfms,
                  aes(x = long,y = lat, fill =type))+
        facet_wrap(~type,nrow = 1,scales = 'free')+
        #ggsci::scale_fill_futurama()+
        scale_fill_manual(values = cols)+
        geom_text(data = facet_labels, aes(x = x, y = y, label = label), 
                  hjust = -0.5, vjust = 1.5, size = 5, fontface = "bold",
                  ) +
        #theme_bw()+
        theme_void()+
        #coord_fixed(1.3)+
        scale_x_continuous(breaks = c(-60,0,60),
                          labels = c('60°W','0°','60°E'),
                          expand = c(0,0))+
        scale_y_continuous(breaks = c(20,60),
                          labels = c('20°N','60°N'))+
        theme(legend.position = 'none')+
        guides(fill = guide_legend(title = ''))+
        text_theme+
        theme(strip.text = element_blank(),
              #axis.title.y = element_text(angle = 90),
              axis.title = element_blank(),
              axis.text.y = element_blank(),
              axis.ticks.length.x = unit(0.15,'cm'),
              axis.line.x = element_line(linewidth = 0.5,color = 'black'),
              axis.ticks = element_line(linewidth = 0.5,color = 'black'),
              )+
        xlab('Longitude')+
        ylab('Latitude')
        
      p
      return(p)
    }
    fig_sub_tranfer2d_03_99_245 <- function(df){
      dfm = reshape2::melt(df,c('long','lat'))
      
      dfm$level = cut(dfm$value,
                      breaks = c(0,1,seq(2003,2069,30),2100),
                      right = FALSE)
      
      dfm1 = dfm[which(dfm$level == '[0,1)'),]
      dfm2 = dfm[which(dfm$level == '[2e+03,2.03e+03)'),]
      dfm3 = dfm[which(dfm$level == '[2.03e+03,2.06e+03)'),]
      dfm3 = rbind(dfm2,dfm3)
      
      dfm4 = dfm[which(dfm$level == '[2.06e+03,2.1e+03)'),]
      dfm4 = rbind(dfm3,dfm4)
      
      dfm1$type = 'A2CN'
      dfm2$type = '2003~2033'
      dfm3$type = '2003~2063'
      dfm4$type = 'A2C1'
      df5 = data.frame(
        long = loc2[,1],
        lat = loc2[,2],
        type = 'System C'
      )
      
      #dfms = rbind(dfm2,dfm3,dfm4)
      dfms = rbind(dfm4,dfm1)
      
      cols_id <- c("#855336", "grey","#CC5500", "#4682B4", "#DAA520")
      
      show_col(cols_id)
      
      cols_id = c('A2C1' = cols_id[5],
                  'A2CN' = cols_id[4],'System C' = cols_id[2])
      
      #uni_label2 = c('A2Cb','A2C1','A2C2','A2CN','C')
      
      source('R/shp_management.R')
      dryland = shp_management('dryland')
      dryland2 = shp_management('dryland_cluster')
      dryland2 = do.call(bind,dryland2)
      dryland = crop(dryland,dryland2)
      world = shp_management('world_new')
      world = crop(world,dryland)
      
      source("R/plot_theme.R")
      text_theme = plot_theme(12)
      
      p = ggplot()+
        geom_polygon(data = dryland,
                    aes(x = long,y = lat,group = group),
                    linewidth = 0.25,
                    fill = 'transparent',
                    color = 'black')+
        # geom_polygon(data = dryland,
        #              aes(x = long,y = lat,group = group),
        #              linewidth = 0.5,
        #              fill = 'grey',)+
        geom_tile(data = df5,
                  aes(x = long,y = lat,fill = type))+
        geom_tile(data = dfms,
                  aes(x = long,y = lat, fill =type))+
        #facet_wrap(~type,nrow = 1,scales = 'free')+
        #ggsci::scale_fill_futurama()+
        scale_fill_manual(values = cols_id)+
        theme_bw()+
        #theme_void()+
        #coord_fixed(1.3)+
        scale_x_continuous(breaks = c(-60,0,60),
                          labels = c('60°W','0°','60°E'),
                          expand = c(0,0))+
        scale_y_continuous(breaks = c(20,60),
                          labels = c('20°N','60°N'))+
        theme(legend.position = 'none')+
        guides(fill = guide_legend(title = ''))+
        text_theme+
        theme(strip.text = element_blank(),
              #axis.title.y = element_text(angle = 90),
              #axis.title = element_blank(),
              #axis.text.y = element_blank(),
              axis.ticks.length.x = unit(0.15,'cm'),
              axis.line.x = element_line(linewidth = 0.5,color = 'black'),
              axis.ticks = element_line(linewidth = 0.5,color = 'black'),
        )+
        xlab('Longitude')+
        ylab('Latitude')
      
      p
      return(p)
    }
    fig_sub_tranfer2d_03_99_585 <- function(df){
      dfm = reshape2::melt(df,c('long','lat'))
      
      dfm$level = cut(dfm$value,
                      breaks = c(0,1,seq(2003,2069,30),2100),
                      right = FALSE)
      
      dfm1 = dfm[which(dfm$level == '[0,1)'),]
      dfm2 = dfm[which(dfm$level == '[2e+03,2.03e+03)'),]
      dfm3 = dfm[which(dfm$level == '[2.03e+03,2.06e+03)'),]
      dfm3 = rbind(dfm2,dfm3)
      
      dfm4 = dfm[which(dfm$level == '[2.06e+03,2.1e+03)'),]
      dfm4 = rbind(dfm3,dfm4)
      
      dfm1$type = 'A2CN'
      dfm2$type = '2003~2033'
      dfm3$type = '2003~2063'
      dfm4$type = 'A2C2'
      df5 = data.frame(
        long = loc2[,1],
        lat = loc2[,2],
        type = 'System C'
      )
      
      #dfms = rbind(dfm2,dfm3,dfm4)
      dfms = rbind(dfm4,dfm1)
      
      cols_id <- c("#855336", "grey","#CC5500", "#4682B4", "#DAA520")
      
      show_col(cols_id)
      
      cols_id = c('A2C2' = cols_id[3],
                  'A2CN' = cols_id[4],'System C' = cols_id[2])
      
      #uni_label2 = c('A2Cb','A2C1','A2C2','A2CN','C')
      
      source('R/shp_management.R')
      dryland = shp_management('dryland')
      dryland2 = shp_management('dryland_cluster')
      dryland2 = do.call(bind,dryland2)
      dryland = crop(dryland,dryland2)
      world = shp_management('world_new')
      world = crop(world,dryland)
      
      source("R/plot_theme.R")
      text_theme = plot_theme(12)
      
      p = ggplot()+
        geom_polygon(data = dryland,
                    aes(x = long,y = lat,group = group),
                    linewidth = 0.25,
                    fill = 'transparent',
                    color = 'black')+
        # geom_polygon(data = dryland,
        #              aes(x = long,y = lat,group = group),
        #              linewidth = 0.5,
        #              fill = 'grey',)+
        geom_tile(data = df5,
                  aes(x = long,y = lat,fill = type))+
        geom_tile(data = dfms,
                  aes(x = long,y = lat, fill =type))+
        #facet_wrap(~type,nrow = 1,scales = 'free')+
        #ggsci::scale_fill_futurama()+
        scale_fill_manual(values = cols_id)+
        theme_bw()+
        #theme_void()+
        #coord_fixed(1.3)+
        scale_x_continuous(breaks = c(-60,0,60),
                          labels = c('60°W','0°','60°E'),
                          expand = c(0,0))+
        scale_y_continuous(breaks = c(20,60),
                          labels = c('20°N','60°N'))+
        theme(legend.position = 'none')+
        guides(fill = guide_legend(title = ''))+
        text_theme+
        theme(strip.text = element_blank(),
              #axis.title.y = element_text(angle = 90),
              #axis.title = element_blank(),
              #axis.text.y = element_blank(),
              axis.ticks.length.x = unit(0.15,'cm'),
              axis.line.x = element_line(linewidth = 0.5,color = 'black'),
              axis.ticks = element_line(linewidth = 0.5,color = 'black'),
        )+
        xlab('Longitude')+
        ylab('Latitude')
      
      p
      return(p)
    }
    
    p245 = fig_sub_tranfer2d_03_99_245(dftips1)
    p585 = fig_sub_tranfer2d_03_99_585(dftips2)
    
    
    fig3d_sub_stat245 <- function(i){
      #print(i)
      tmp = tipid_245[,i]
      group_id_by_years <- function(x){
        dates = seq(as.Date('2003-07-01'),
                    as.Date('2099-06-01'),
                    '1 month')
        if(x == 0 | is.na(x)){
          tmpdate = 0
        }else{
          tmpdate = substr(dates[round(x)],1,4)
          tmpdate = as.numeric(tmpdate)
        }
        return(tmpdate)
      }
      tmpdate = sapply(tmp,group_id_by_years)
      
      level = cut(tmpdate,
                  breaks = c(0,1,
                            2003,2033,2063,
                            2100),
                  right = FALSE)
      
      len0 = length(which(level == '[0,1)'))
      len1 = length(which(level == '[2e+03,2.03e+03)'))
      len2 = length(which(level == '[2.03e+03,2.06e+03)'))
      len3 = length(which(level == '[2.06e+03,2.1e+03)'))
      
      stat1 = c(len1,len1+len2,
                len3+len1+len2)
      stat1 = stat1/19911*100
      
      return(stat1)
    }
    
    fig3d_sub_stat585<- function(i){
      #print(i)
      tmp = tipid_585[,i]
      group_id_by_years <- function(x){
        dates = seq(as.Date('2003-07-01'),
                    as.Date('2099-06-01'),
                    '1 month')
        if(x == 0 | is.na(x)){
          tmpdate = 0
        }else{
          tmpdate = substr(dates[round(x)],1,4)
          tmpdate = as.numeric(tmpdate)
        }
        return(tmpdate)
      }
      tmpdate = sapply(tmp,group_id_by_years)
      
      level = cut(tmpdate,
                  breaks = c(0,1,
                            2003,2033,2063,
                            2100),
                  right = FALSE)
      
      len0 = length(which(level == '[0,1)'))
      len1 = length(which(level == '[2e+03,2.03e+03)'))
      len2 = length(which(level == '[2.03e+03,2.06e+03)'))
      len3 = length(which(level == '[2.06e+03,2.1e+03)'))
      
      stat1 = c(len1,len1+len2,
                len3+len1+len2)
      stat1 = stat1/19911*100
      
      return(stat1)
    }
    
    i = 1:21
    #stats1 = do.call(rbind,lapply(i,fig3d_sub_stat245))
    #stats2 = do.call(rbind,lapply(i,fig3d_sub_stat585))
    
    output1 = 'data_for_sharing/Figure4/transfer_ratio_245.csv'
    output2 = 'data_for_sharing/Figure4/transfer_ratio_585.csv'
    
    #fwrite(stats1,output1)
    #fwrite(stats2,output2)
    stats1 = as.data.frame(fread(output1))
    stats2 = as.data.frame(fread(output2))
    
    stats1_quan = apply(stats1,2,quantile)
    stats2_quan = apply(stats2,2,quantile)
    
    stats_quan1 = t(stats1_quan)
    stats_quan2 = t(stats2_quan)
    
    stats_quan1 = as.data.frame(stats_quan1)
    stats_quan2 = as.data.frame(stats_quan2)
    
    colnames(stats_quan1) = c('y0','y25','y50','y75','y100') 
    colnames(stats_quan2) = c('y0','y25','y50','y75','y100') 
    
    stats_quans = rbind(stats_quan1[3,],
                        stats_quan2[3,])
    stats_quans$x = c('SSP245','SSP585')
    
    stats_quan1$x = c('2003~2033','2003~2063','2003~2099')
    stats_quan2$x = c('2003~2033','2003~2063','2003~2099')
    stats_quan1$color = c('2003~2033','2003~2063','2003~2099')
    stats_quan2$color = c('2003~2033','2003~2063','2003~2099')
    
    # stats21 = do.call(rbind,lapply(21,fig3d_sub_stat245))
    # stats22 = do.call(rbind,lapply(21,fig3d_sub_stat585))
    # 
    output1 = 'data_for_sharing/Figure4/stats21_id.csv'
    output2 = 'data_for_sharing/Figure4/stats22_id.csv'
    # fwrite(data.frame(stats21),output1)
    # fwrite(data.frame(stats22),output2)
    stats21 = as.matrix(as.data.frame(fread(output1)))
    stats22 = as.matrix(as.data.frame(fread(output2)))
    
    
    dfs1 = data.frame(
      x = -80,
      y = 50,
      label = paste0('A2C/A Ratio: \n',round(as.numeric(stats21[1,])),'%'),
      type = c('2003~2033','2003~2063','2003~2099')
    )
    
    dfs2 = data.frame(
      x = -80,
      y = 50,
      label = paste0('A2C/A Ratio: \n',round(as.numeric(stats22[1,])),'%'),
      type = c('2003~2033','2003~2063','2003~2099')
    )
    
    
    dfs1p = data.frame(
      y = as.numeric(stats21[1,]),
      x = c('2003~2033','2003~2063','2003~2099')
    )
    
    dfs2p = data.frame(
      y = as.numeric(stats22[1,]),
      x = c('2003~2033','2003~2063','2003~2099')
    )
    
    
    
    p245 = p245 + 
      geom_text(data = dfs1[3,],
                aes( x= x,y = y,label = label),
                size = 4,
                hjust = 0)
    p585 = p585 + 
      geom_text(data = dfs2[3,],
                aes( x= x,y = y,label = label),
                size = 4,
                hjust = 0) 
    
    
    cols = ggsci::pal_futurama()(4)[1:3]
    source("R/plot_theme.R")
    text_theme = plot_theme(12)
    cols = c('2003~2033'=cols[3],
            '2003~2063'=cols[1],
            '2003~2099'=cols[2])
    
    pbar1 = ggplot()+
      geom_boxplot(data = stats_quan1,
              aes(x = x,ymin = y0, lower = y25, middle = y50, upper = y75, ymax = y100,
                  fill = color),
              width = 0.25,
              stat = 'identity',
              position = position_dodge2(0.25))+
      geom_point(data = dfs1p,
                aes(x= x,y = y),
                shape = 5,
                size = 3)+
      # geom_text(data = dfs1,
      #            aes(x= x,y = y,label = paste0(round(y),'%')),
      #            size = 4,
      #            nudge_x = 0.2,
      #           nudge_y = -0.1)+
      geom_text(data = stats_quan1,
                aes(x = x,y = y50,
                    label = paste0(round(y50),'%')),
                size = 4,color = 'black',
                nudge_x = -0.2)+
      theme_bw()+
      #scale_x_continuous(breaks = c(1,2,3),
      #                   labels = rev(c('2003~2033','2003~2063','2003~2099')))+
      # scale_y_continuous(limits = c(25,110),
      #                   breaks = c(25,50,75,100),
      #                   labels = c(25,50,75,100))+
      text_theme+
      theme(legend.position = 'none')+
      scale_fill_manual(values = cols)+
      theme(panel.grid = element_blank(),
            plot.background = element_blank(),
            panel.border = element_blank(),
            axis.line = element_line(linewidth = 0.5,
                                    color = 'black',
                                    arrow = arrow(20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'closed')),
            axis.title = element_blank())+
      xlab('Time')+
      ylab("Percentage of pixels (%)")+
      coord_flip()
    #pbar1
    
    
    cols = ggsci::pal_futurama()(4)[1:3]
    source("R/plot_theme.R")
    text_theme = plot_theme(12)
    cols = c('2003~2033'=cols[3],
            '2003~2063'=cols[1],
            '2003~2099'=cols[2])
    pbar2 = ggplot()+
      geom_boxplot(data = stats_quan2,
                  aes(x = x,ymin = y0, lower = y25, middle = y50, upper = y75, ymax = y100,
                      fill = color),
                  width = 0.25,
                  stat = 'identity',
                  position = position_dodge2(0.25))+
      geom_point(data = dfs2p,
                aes(x= x,y = y),
                shape = 5,
                size = 3)+
      # geom_text(data = dfs2,
      #           aes(x= x,y = y,label = paste0(round(y),'%')),
      #           size = 4,
      #           nudge_x = c(-0.1,-0.2,-0.1)-0.1,
      #           nudge_y = -0.2)+
      geom_text(data = stats_quan2,
                aes(x = x,y = y50,
                    label = paste0(round(y50),'%')),
                size = 4,color = 'black',
                nudge_x = 0.2)+
      theme_bw()+
      #scale_x_continuous(breaks = c(1,2,3),
      #                   labels = rev(c('2003~2033','2003~2063','2003~2099')))+
      # scale_y_continuous(limits = c(25,110),
      #                    breaks = c(25,50,75,100),
      #                    labels = c(25,50,75,100))+
      text_theme+
      theme(legend.position = 'none')+
      scale_fill_manual(values = cols)+
      theme(panel.grid = element_blank(),
            plot.background = element_blank(),
            panel.border = element_blank(),
            axis.line = element_line(linewidth = 0.5,
                                    color = 'black',
                                    arrow = arrow(20,
                                                  length = unit(0.25,'cm'),
                                                  type = 'closed')),
            axis.title = element_blank())+
      xlab('Time')+
      ylab("Percentage of pixels (%)")+
      coord_flip()
    #pbar2
    
    dfs2p1= dfs2p[3,]
    dfs1p1 = dfs1p[3,]
    dfsp12 = rbind(dfs1p1,
                  dfs2p1)
    dfsp12$x = c('SSP245','SSP585')
    
    dfsp12_y = as.numeric(dfsp12$y)
    
    print(dfsp12_y)
    pbar3 = ggplot()+
      geom_boxplot(data = stats_quans,
                  aes(x = x,ymin = y0, lower = y25, middle = y50, 
                      upper = y75, ymax = y100),
                  fill = 'grey',
                  width = 0.35,
                  linewidth = 0.1,
                  stat = 'identity',
                  position = position_dodge2(0.25))+
      geom_point(data = dfsp12,
                aes(x= x,y = y),
                shape = 5,
                size = 2)+
      # geom_text(data = dfs2,
      #           aes(x= x,y = y,label = paste0(round(y),'%')),
      #           size = 4,
      #           nudge_x = c(-0.1,-0.2,-0.1)-0.1,
      #           nudge_y = -0.2)+
      geom_text(data = stats_quans,
                aes(x = x,y = y50,
                    label = paste0(round(y50),'%')),
                size = 4,color = 'black',
                nudge_y = 0.2,
                nudge_x = 0.2)+
      #$theme_bw()+
      #heme_cowplot()+
      #scale_x_continuous(breaks = c(1,2,3),
      #                   labels = rev(c('2003~2033','2003~2063','2003~2099')))+
      # scale_y_continuous(limits = c(25,110),
      #                    breaks = c(25,50,75,100),
      #                    labels = c(25,50,75,100))+
      text_theme+
      theme_void()+
      theme(
        axis.line.x = element_line(linewidth = 0.25,
                                      color = 'black'),
        axis.text.x = element_text(size = 10,
                                  color= 'black')
      )+
      theme(legend.position = 'none')+
      scale_fill_manual(values = cols)+
      geom_hline(aes(yintercept= c(dfsp12_y[1],
                                  stats_quans[,3],
                                  dfsp12_y[2])),
                linetype = 'dashed',
                color = 'grey',
                linewidth = 0.15)+
      scale_y_continuous(breaks = c(dfsp12_y[1],
                                    stats_quans[,3],
                                    dfsp12_y[2]),
                        labels = c(60,72,79,83))+
      xlab('Time')+
      ylab("Percentage of pixels (%)")+
      coord_flip()
    
    library(cowplot)
   
    
    return(list(p245,p585,pbar3))
  }

  fig4_density_gpp_transfer_both245_585 <- function(
  ){
    
    dfmap = as.data.frame(fread('data_for_sharing/Figure4/mutual_transfer_df_245_585.csv'))
    
    cols_id <- c("#855336", "grey","#CC5500", "#4682B4", "#DAA520")
    
    show_col(cols_id)
    
    cols_id = c('2' = cols_id[1], # A2Cb
                '3' = cols_id[3], # A2C2
                '4' = cols_id[5], # A2C1
                '5' = cols_id[4], # A2CN
                '1' = cols_id[2] # C
                )
    # cols_id = c('2' = cols_id[1], # A2C
    #             '3' = cols_id[3],
    #             '4' = cols_id[5],
    #             '5' = cols_id[4],
    #             '1' = cols_id[2]
    # )
    uni_label2 = c('C','A2Cb','A2C2','A2C1','A2CN')
    
    stat_fun <-function(i){
      tmp = length(which(dfmap$class == i))/nrow(dfmap)*100
      return(tmp)
    }
    
    ret_stat = do.call(c,lapply(1:5,stat_fun))
    ret_stat = round(ret_stat)
    
    dfstat = data.frame(
      x = 1:5,
      y = ret_stat[c(5,1:3,4)]
      
    )
    source("R/plot_theme.R")
    dfseg1 = data.frame(
      x = c(1,4),
      xend = c(4,5),
      y = 36
    )
    source("R/plot_theme.R")
    dfseg2 = data.frame(
      xend = c(1,4),
      x = c(4,5),
      y = 36
    )
    dfseg1= rbind(dfseg1,dfseg2)
    dfseg3 =data.frame(
      x = c(1,4,5),
      y = 34,
      yend = 38
    )
    dftexts = data.frame(
      x = c(2.5,4.5),
      y = 37,
      label = paste0(c(100-ret_stat[4],ret_stat[4]),'%')
    )
    text_theme = plot_theme(12)
    p1= ggplot() +
      geom_segment(data = dfseg1,
                  aes(x = x,xend = xend,y = y+5,yend = y+5),
                  linewidth = 0.5,,color = 'black',
                  arrow = arrow(20,unit(0.25,'cm'),type = 'closed'))+
      geom_segment(data = dfseg3,
                  aes(x = x,xend = x,y = y+5,yend = yend+5),
                  linewidth = 0.5,,color = 'black')+
      geom_text(data = dftexts,
                aes(x = x,y = y+5,
                    label = label),
                size = 4,color = 'black')+
      geom_bar(data = dfstat,
              aes(x = x,y = y,fill = as.factor(x)),
              stat = 'identity',
              width = 0.5,
              position = position_dodge2(0.5))+
      geom_text(data = dfstat,
              aes(x = x,y = y+2,label = 
                    paste0(round(y),'%')),
              position = position_dodge2(0.5))+
      scale_fill_manual(values = cols_id)+
      theme_bw()+
      text_theme+
      scale_x_continuous(breaks = c(1:5),
                        labels = uni_label2,
                        limits = c(0.5,5.5))+
      #scale_y_continuous(limits = c(0,42))+
      theme(legend.position = 'bottom')+
      xlab('System transfer types')+
      ylab("Ratio (%)")
    
    
    return(p1)
    
  }

  fig4_ensemble_trans_map <- function(
  ){

    dfmap = as.data.frame(fread('data_for_sharing/Figure4/mutual_transfer_df_245_585.csv'))
    
    cols_id <- c("#855336", "grey","#CC5500", "#4682B4", "#DAA520")
    
    show_col(cols_id)
    
    # cols_id = c('1' = cols_id[2], # C
    #             '2' = cols_id[1], # A2Cb
    #             '3' = cols_id[3], # A2C2
    #             '4' = cols_id[5], # A2C1
    #             '5' = cols_id[4], # A2CN
    #             
    # )
    
    cols_id = c(
      '1' = cols_id[1], # A2Cb
      '2' = cols_id[3], # A2C2
      '3' = cols_id[5], # A2C1
      '4' = cols_id[4], # A2CN
      '5' = cols_id[2] # C
      
    )
    source('R/shp_management.R')
    dryland = shp_management('dryland')
    dryland2 = shp_management('dryland_cluster')
    dryland2 = do.call(bind,dryland2)
    dryland = crop(dryland,dryland2)
    world = shp_management('world_new')
    world = crop(world,extent(-180,180,0,90))
    source("R/plot_theme.R")
    text_theme = plot_theme(12)
    
    p = ggplot()+
      geom_hline(yintercept = c(20,60),
                linetype = 'dashed',
                color = 'black',linewidth = 0.5)+
      geom_polygon(data = world,
                  aes(x = long,y = lat,group = group),
                  linewidth = 0.25,
                  fill = 'transparent',
                  color = 'black')+
      geom_polygon(data = dryland,
                  aes(x = long,y = lat,group = group),
                  linewidth = 0.25,
                  fill = 'transparent',
                  color = 'black')+
      # geom_polygon(data = dryland,
      #              aes(x = long,y = lat,group = group),
      #              linewidth = 0.5,
      #              fill = 'grey',)+
      geom_tile(data = dfmap,
                aes(x = long,y = lat, fill =as.factor(class)))+
      #facet_wrap(~type,nrow = 1,scales = 'free')+
      #ggsci::scale_fill_futurama()+
      scale_fill_manual(values = cols_id)+
      #theme_bw()+
      theme_bw()+
      #theme_void()+
      #coord_fixed(1.3)+
      scale_x_continuous(breaks = c(-60,0,60),
                        labels = c('60°W','0°','60°E'),
                        expand = c(0, 0))+
      scale_y_continuous(breaks = c(20,60),
                        labels = c('20°N','60°N'))+
      theme(legend.position = 'none')+
      guides(fill = guide_legend(title = ''))+
      text_theme+
      theme(strip.text = element_blank(),
            axis.title.y = element_text(angle = 90),
            axis.text.y = element_text(angle = 90),
            #axis.title = element_blank(),
            #axis.text.y = element_blank(),
            axis.ticks.length.x = unit(0.15,'cm'),
            axis.line.x = element_line(linewidth = 0.5,color = 'black'),
            axis.ticks = element_line(linewidth = 0.5,color = 'black'),
      )+
      xlab('Longitude')+
      ylab('Latitude')
    
    p
    
    return(p)
    
    
  }

  # shift of tip id 
  pbars = fig_tip_year_ssp245_585_ensemble_2d()
  
  pbar1 = pbars[[1]]
  pbar2 = pbars[[2]]  
  pbar3 = pbars[[3]]  
  
  #pbar3 = pbar3+theme_void()
  # output_bar = 'main_plot/Figure4/box_plot.pdf'
  # ggsave(output_bar,pbar3,width = 4.5,height = 1.5,units = 'cm',
  #        dpi = 800)
  
 
  source("R/fig4_density_gpp_transfer_both245_585.R")
  pbar_mutual = fig4_density_gpp_transfer_both245_585()
  
  pbar_mutual = pbar_mutual +
    theme(legend.position = 'none')
 
  source("R/plot_theme.R")
  text_theme = plot_theme(12)
    
  bar_theme = theme_void()+
    text_theme+
    theme(axis.line.x = element_line(linewidth = 0.5,
                                     color = 'black'),
          axis.text.y = element_blank(),
          axis.title.y = element_blank(),
          axis.ticks.x = element_line(linewidth = 0.5,
                                      color = 'black'),
          axis.ticks.length.x = unit(0.25,'cm'),
          axis.title.x = element_text(margin = margin(t = 0.15, unit = "cm")),
          legend.position = 'none')
  
  bar_map_theme = theme(
    axis.text.y = element_blank(),
    axis.title = element_blank(),
    plot.background = element_blank(),
    panel.background = element_blank(),
    panel.border = element_blank(),
    axis.ticks.y = element_blank(),
    axis.line.x = element_blank()
  )
  bar_map_theme1 = theme(
    #axis.text.y = element_blank(),
    axis.title = element_blank(),
    plot.background = element_blank(),
    panel.background = element_blank(),
    panel.border = element_blank(),
    axis.ticks.y = element_blank(),
    axis.line.x = element_blank()
  )
  pbar1 = pbar1+bar_map_theme+coord_fixed(1.3)#+theme(plot.margin = margin(0, 0, 0, 0, "cm"))
  pbar2 = pbar2+bar_map_theme+coord_fixed(1.3)#+theme(plot.margin = margin(0, 0, 0, 0, "cm"))
  
  
  pbar_mutual1 = pbar_mutual+
    coord_flip()+
    theme(panel.border = element_blank(),
          axis.title = element_blank(),
          axis.line = element_line(
            linewidth = 0.5,linetype = 'solid',
            color = 'black',
            arrow = arrow(20,unit(0.3,'cm'),type = 'closed')
          ))
  
  pmutal_map = fig4_ensemble_trans_map()
  
  theme_panel_border= theme(
    panel.border = element_rect(linetype = 'solid',linewidth = 0.5,color = 'black',
                                fill = 'transparent')
  )
  
  prow0 = pmutal_map+bar_map_theme1+
    theme(axis.title.y = element_blank())+#theme_panel_border+
    coord_fixed(1.3)
  
  prow1 = plot_grid(pbar1+#theme_panel_border+
                      coord_fixed(1.3),
                    pbar2+#theme_panel_border+
                      coord_fixed(1.3),nrow = 1)
  column_plot <- plot_grid(prow0,prow1,rel_heights = c(2,1),ncol = 1)
  
  # output = 'main_plot/Figure4/fig4_com.pdf'
  # ggsave(output,column_plot,width =18,height = 10,units = 'cm')
  
  # output = 'main_plot/Figure4/fig4_com_pline.pdf'
  # ggsave(output,pline,width =18,height = 8,units = 'cm')
  
  # output = 'main_plot/Figure4/fig4_com_pbar.pdf'
  # ggsave(output,pbar_mutual1,width = 4,height = 10,units = 'cm')  
  
  
 
}